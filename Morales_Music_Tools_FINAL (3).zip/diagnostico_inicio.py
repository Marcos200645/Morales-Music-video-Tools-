"""Diagnóstico de apertura; no modifica la instalación de Windows."""
import importlib
import importlib.metadata
import logging
import platform
import struct
import sys
from pathlib import Path


def preparar_registro(carpeta):
    carpeta.mkdir(parents=True, exist_ok=True)
    ruta = carpeta / 'inicio_error.txt'
    registro = logging.getLogger('webview')
    manejador = logging.FileHandler(ruta, mode='w', encoding='utf-8')
    manejador.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
    registro.addHandler(manejador)
    registro.setLevel(logging.DEBUG)
    registro.info('Morales Music Tools 4.1 | %s | Python %s | %s bits | EXE=%s',
                  platform.platform(), platform.python_version(), struct.calcsize('P')*8,
                  bool(getattr(sys, 'frozen', False)))
    for paquete in ('pywebview', 'pythonnet', 'clr-loader', 'Pillow'):
        try:
            version = importlib.metadata.version(paquete)
        except importlib.metadata.PackageNotFoundError:
            version = 'sin metadatos (puede estar integrado en el EXE)'
        registro.info('%s: %s', paquete, version)
    if sys.platform == 'win32':
        import winreg
        # Solo consulta el registro de productos Edge; no lo modifica.
        for raiz, nombre in ((winreg.HKEY_CURRENT_USER, 'usuario'), (winreg.HKEY_LOCAL_MACHINE, 'equipo')):
            for vista in (winreg.KEY_WOW64_32KEY, winreg.KEY_WOW64_64KEY):
                try:
                    with winreg.OpenKey(raiz, r'SOFTWARE\Microsoft\EdgeUpdate\Clients', 0,
                                        winreg.KEY_READ | vista) as llave:
                        indice = 0
                        while True:
                            try:
                                sub = winreg.EnumKey(llave, indice)
                            except OSError:
                                break
                            indice += 1
                            try:
                                with winreg.OpenKey(llave, sub) as producto:
                                    titulo = winreg.QueryValueEx(producto, 'name')[0]
                                    version = winreg.QueryValueEx(producto, 'pv')[0]
                                    if 'webview' in titulo.lower():
                                        registro.info('WebView2 registrado (%s, vista %s): %s %s', nombre, vista, titulo, version)
                            except OSError:
                                continue
                except OSError:
                    continue
    return registro, ruta


def explicar_error(error):
    if isinstance(error, ModuleNotFoundError):
        return ('Falta un componente de Python: ' + str(error.name) +
                '.\nEjecuta INSTALAR_Morales_Music_Tools.bat y abre el programa con EJECUTAR_Morales_Music_Tools.bat. '
                'Si usas el EXE, vuelve a crearlo con el paquete actualizado.')
    if isinstance(error, FileNotFoundError):
        return ('Falta un archivo del programa. Extrae todo el ZIP. Si usas el EXE, '
                'vuelve a crearlo con CREAR_EXE_Morales_Music_Tools.bat; '
                'el nuevo EXE debe llevar los recursos integrados.')
    return ('No se pudo iniciar la interfaz. Este mensaje NO confirma que falte WebView2. '
            'El detalle real está en el registro. Envíalo para identificar el componente que falla.')

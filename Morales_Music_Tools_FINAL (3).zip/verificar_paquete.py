"""Comprueba recursos y conversion real sin abrir ventanas ni usar internet."""
import json
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path


def verificar():
    import yt_dlp
    import webview
    import imageio_ffmpeg
    from PIL import Image
    import Morales_Music_Tools as core
    from interfaz_moderna import construir_html

    for nombre in ('Morales_Music_Tools_Logo.png', 'Morales_Music_Tools.ico',
                   'web/index.html', 'web/style.css', 'web/app.js',
                   'web/studio.css', 'web/studio.js', 'web/studio_model.js'):
        if not core.ruta_recurso(nombre).is_file():
            raise FileNotFoundError(nombre)
    html = construir_html()
    if not html or len(html) < 1000:
        raise RuntimeError('La interfaz no se pudo preparar.')
    # Usa el motor del paquete, nunca uno instalado por separado en PATH.
    motor = Path(imageio_ffmpeg.get_ffmpeg_exe())
    if getattr(sys, 'frozen', False):
        motor.resolve().relative_to(Path(sys._MEIPASS).resolve())
    with tempfile.TemporaryDirectory(prefix='mmt_audio_') as carpeta:
        salida = Path(carpeta) / 'prueba.mp3'
        subprocess.run([str(motor), '-y', '-f', 'lavfi', '-i',
                        'sine=frequency=440:duration=0.1', '-c:a', 'libmp3lame',
                        str(salida)], check=True, capture_output=True, timeout=30,
                       creationflags=0x08000000 if sys.platform == 'win32' else 0)
        if salida.stat().st_size < 100:
            raise RuntimeError('El motor no produjo el MP3 de prueba.')
    return {'correcto': True, 'ffmpeg': str(motor), 'interfaz': True,
            'ejecutable': bool(getattr(sys, 'frozen', False))}


def guardar_informe(destino):
    try:
        resultado = verificar()
    except Exception:
        resultado = {'correcto': False, 'error': traceback.format_exc()}
    Path(destino).write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if resultado['correcto'] else 1

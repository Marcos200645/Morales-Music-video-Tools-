"""Constructor para Windows: archivo unico y comprobacion fuera del proyecto."""
import json
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

BASE = Path(__file__).resolve().parent


def main():
    if sys.platform != 'win32':
        raise RuntimeError('El EXE de Windows debe construirse en Windows.')
    from verificar_paquete import verificar
    verificar()
    comando = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
               '--onefile', '--windowed', '--noupx', '--name', 'Morales_Music_Tools',
               '--icon', str(BASE / 'Morales_Music_Tools.ico')]
    for recurso, destino in [('Morales_Music_Tools_Logo.png', '.'),
                             ('Morales_Music_Tools.ico', '.'), ('web', 'web')]:
        comando += ['--add-data', str(BASE / recurso) + ';' + destino]
    for paquete in ('yt_dlp', 'imageio_ffmpeg', 'webview', 'pythonnet', 'clr_loader'):
        comando += ['--collect-all', paquete]
    comando += ['--hidden-import', 'PIL.ImageTk', '--hidden-import', 'webview.platforms.winforms']
    for paquete in ('PySide6', 'PyQt5', 'PyQt6'):
        comando += ['--exclude-module', paquete]
    comando += [str(BASE / 'Morales_Music_Tools.py')]
    subprocess.run(comando, cwd=BASE, check=True)
    exe = BASE / 'dist' / 'Morales_Music_Tools.exe'
    if not exe.is_file():
        raise FileNotFoundError('No se genero el EXE esperado.')
    print('Comprobando una copia del EXE sin archivos del proyecto...', flush=True)
    informe_final = BASE / 'comprobacion_exe.json'
    with tempfile.TemporaryDirectory(prefix='MMT prueba ') as carpeta:
        carpeta = Path(carpeta)
        copia = carpeta / exe.name
        shutil.copy2(exe, copia)
        informe = carpeta / 'resultado.json'
        proceso = subprocess.run([str(copia), '--verificar-paquete', str(informe)],
                                 cwd=carpeta, timeout=180)
        if not informe.is_file():
            raise RuntimeError('El EXE no genero su informe de prueba. Revisa la salida de compilacion.')
        shutil.copy2(informe, informe_final)
        resultado = json.loads(informe.read_text(encoding='utf-8'))
        if proceso.returncode or not resultado.get('correcto'):
            raise RuntimeError('Fallo el EXE aislado: ' + str(resultado.get('error')))
    print('\nEXE creado y componentes comprobados:\n' + str(exe))
    print('Puedes copiar SOLO ese EXE. Prueba tambien abrirlo normalmente.')
    print('Windows necesita WebView2 Runtime; la prueba no abre la ventana.')


if __name__ == '__main__':
    try:
        main()
    except Exception:
        detalle = traceback.format_exc()
        (BASE / 'error_crear_exe.txt').write_text(detalle, encoding='utf-8')
        print(detalle)
        print('No se completo la creacion. Detalle: error_crear_exe.txt')
        sys.exit(1)

@echo off
setlocal
cd /d "%~dp0"
echo Se actualizaran los componentes y se creara un nuevo EXE unico.
call "CREAR_EXE_Morales_Music_Tools.bat"
exit /b %errorlevel%

@echo off
setlocal
cd /d "%~dp0"
title Instalar Morales Music Tools
if exist ".venv\Scripts\python.exe" goto :validar
where py >nul 2>nul
if not errorlevel 1 goto :con_py
where python >nul 2>nul
if not errorlevel 1 goto :con_python
echo No se encontro Python. Instala Python 3.11 o 3.12 de 64 bits.
goto :error
:con_py
py -3 -m venv ".venv"
if errorlevel 1 goto :error
goto :validar
:con_python
python -m venv ".venv"
if errorlevel 1 goto :error
:validar
".venv\Scripts\python.exe" -c "import sys, struct; sys.exit(0 if sys.version_info >= (3, 10) and struct.calcsize('P') == 8 else 1)"
if errorlevel 1 goto :entorno_roto
".venv\Scripts\python.exe" -m pip install --upgrade -r "requirements_Morales_Music_Tools.txt"
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -c "from verificar_paquete import guardar_informe; import sys; sys.exit(guardar_informe('comprobacion_instalacion.json'))"
if errorlevel 1 goto :error
echo Instalacion y conversion MP3 verificadas.
echo Abre el programa con EJECUTAR_Morales_Music_Tools.bat.
if /I not "%~1"=="/auto" pause
exit /b 0
:entorno_roto
echo El entorno .venv no funciona o no es Python 3.10+ de 64 bits.
echo Extrae el ZIP en una carpeta nueva y usa Python 3.11 o 3.12 de 64 bits.
:error
echo No se completo la instalacion. Revisa el mensaje anterior.
echo Si existe, revisa tambien comprobacion_instalacion.json.
if /I not "%~1"=="/auto" pause
exit /b 1

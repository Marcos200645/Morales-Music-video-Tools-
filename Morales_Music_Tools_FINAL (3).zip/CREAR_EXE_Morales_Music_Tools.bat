@echo off
setlocal
cd /d "%~dp0"
title Crear EXE unico - Morales Music Tools
call "INSTALAR_Morales_Music_Tools.bat" /auto
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m pip install --upgrade pyinstaller pyinstaller-hooks-contrib
if errorlevel 1 goto :error
".venv\Scripts\python.exe" "crear_exe.py"
if errorlevel 1 goto :error
echo.
echo Resultado: dist\Morales_Music_Tools.exe
echo Copia SOLO ese archivo. No necesitas los BAT ni los PY para usarlo.
echo La primera apertura puede tardar al extraer los componentes internos.
start "" "%CD%\dist"
pause
exit /b 0
:error
echo.
echo NO se completo la creacion. No uses un EXE antiguo como si fuera nuevo.
echo Revisa el mensaje anterior y error_crear_exe.txt si existe.
pause
exit /b 1

@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto :instalar
".venv\Scripts\python.exe" -c "import webview, yt_dlp, imageio_ffmpeg; from PIL import Image"
if errorlevel 1 goto :instalar
goto :abrir
:instalar
call "INSTALAR_Morales_Music_Tools.bat" /auto
if errorlevel 1 goto :error
:abrir
".venv\Scripts\python.exe" "Morales_Music_Tools.py"
if errorlevel 1 goto :error
exit /b 0
:error
echo No se pudo abrir. Revisa el mensaje y VER_ERROR_DE_INICIO.bat.
pause
exit /b 1

"""Interfaz HTML/CSS local; reutiliza el motor multimedia sin crear ventanas Tk."""
import base64
import io
import json
import math
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
import wave
from collections import OrderedDict
from dataclasses import asdict
from pathlib import Path

import Morales_Music_Tools as core
from editor_visual import analizar_audio


class Valor:
    def __init__(self, valor):
        self.valor = valor

    def get(self):
        return self.valor


class Eventos:
    def __init__(self, api):
        self.api = api

    def put(self, evento):
        self.api._evento(evento)


class Motor:
    """Solo métodos de procesamiento: ningún acceso a variables de Tk."""
    descargar = core.AudioFacil.descargar
    descargar_video = core.AudioFacil.descargar_video
    convertir = core.AudioFacil.convertir
    expandir_enlace = core.AudioFacil.expandir_enlace
    descargar_subtitulos_video = core.AudioFacil.descargar_subtitulos_video
    descargar_formato_video = core.AudioFacil.descargar_formato_video
    unir_video_audio = core.AudioFacil.unir_video_audio
    procesar_edicion = core.AudioFacil.procesar_edicion
    ejecutar_ffmpeg_editor = core.AudioFacil.ejecutar_ffmpeg_editor
    elegir_formatos_video = staticmethod(core.AudioFacil.elegir_formatos_video)
    verificar_archivo_video = staticmethod(core.AudioFacil.verificar_archivo_video)
    verificar_formato_audio = staticmethod(core.AudioFacil.verificar_formato_audio)
    obtener_duracion = staticmethod(core.AudioFacil.obtener_duracion)
    tiempo_a_segundos = staticmethod(core.AudioFacil.tiempo_a_segundos)

    def __init__(self, api, carpeta):
        self.carpeta = Valor(carpeta)
        self.cancelar_actual = threading.Event()
        self.proceso_actual = None
        self.eventos = Eventos(api)


class Api:
    def __init__(self):
        self._window = None
        self._lock = threading.RLock()
        self._decode_lock = threading.RLock()
        self._preview_lock = threading.Lock()
        self._preview_cache = None
        self._temp = tempfile.TemporaryDirectory(prefix='mmt_studio_')
        self._cache = OrderedDict()
        self._files = {}
        self._jobs = []
        self._revision = 0
        self._busy = False
        self._searching = False
        self._paused = threading.Event()
        self._closed = threading.Event()
        self._active = None
        self._message = 'Listo para crear'
        self._progress = 0
        self._error = ''
        try:
            config = json.loads(core.CONFIG_FILE.read_text(encoding='utf-8'))
            self._folder = config.get('carpeta', str(Path.home()/'Downloads'))
        except (OSError, ValueError):
            self._folder = str(Path.home()/'Downloads')
        try:
            self._history = json.loads(core.HISTORIAL_FILE.read_text(encoding='utf-8'))
            if not isinstance(self._history, list):
                self._history = []
        except (OSError, ValueError):
            self._history = []
        self._motor = Motor(self, self._folder)

    def _evento(self, evento):
        with self._lock:
            tipo = evento[0]
            if tipo == 'canciones_parciales':
                for entrada in evento[1]:
                    if any(j.origen == entrada['url'] and j.tipo == entrada['tipo'] for j in self._jobs):
                        continue
                    self._jobs.append(core.Trabajo(
                        id=int(uuid.uuid4().int % 10**12), tipo=entrada['tipo'],
                        origen=entrada['url'], formato=entrada['formato'],
                        titulo=entrada['titulo'], miniatura=entrada['miniatura'],
                        calidad=entrada['calidad'], estado='Disponible',
                        subtitulos=entrada['subtitulos'], idioma_subtitulos=entrada['idioma_subtitulos']))
            elif tipo == 'progreso':
                self._progress = evento[1].progreso
            elif tipo == 'editor_progreso':
                self._progress = evento[1]
            elif tipo == 'editor_fin':
                self._progress = 100
                self._message = 'Exportación terminada: ' + Path(evento[1]).name
                self._registrar(evento[1], evento[2])
            elif tipo in ('editor_error', 'enlace_error'):
                self._error = evento[1]
                self._message = 'No se pudo completar la operación'
                self._log(evento[1], evento[2] if len(evento) > 2 else '')
            elif tipo == 'editor_cancelado':
                self._message = 'Exportación cancelada'
            self._revision += 1

    def _log(self, error, detalle=''):
        core.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with (core.CONFIG_DIR/'errores.txt').open('a', encoding='utf-8') as f:
            f.write(f'\n{time.ctime()}: {error}\n{detalle}\n')

    def _registrar(self, ruta, operacion):
        self._history.insert(0, {'fecha': time.strftime('%Y-%m-%d %H:%M'),
                                'nombre': Path(ruta).name, 'tipo': operacion, 'ruta': ruta})
        self._history = self._history[:500]
        core.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        temporal = core.HISTORIAL_FILE.with_suffix('.tmp')
        temporal.write_text(json.dumps(self._history, ensure_ascii=False), encoding='utf-8')
        temporal.replace(core.HISTORIAL_FILE)

    def estado(self, revision=-1):
        with self._lock:
            if revision == self._revision:
                return None
            return {'revision': self._revision, 'jobs': [asdict(j) for j in self._jobs],
                    'history': list(self._history), 'busy': self._busy, 'searching': self._searching,
                    'paused': self._paused.is_set(), 'active': self._active,
                    'progress': self._progress, 'message': self._message,
                    'error': self._error, 'folder': self._folder}

    def carpeta(self):
        import webview
        rutas = self._window.create_file_dialog(webview.FileDialog.FOLDER)
        if rutas:
            with self._lock:
                self._folder = rutas[0]
                core.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
                try:
                    config = json.loads(core.CONFIG_FILE.read_text(encoding='utf-8'))
                except (OSError, ValueError):
                    config = {}
                config['carpeta'] = self._folder
                core.CONFIG_FILE.write_text(json.dumps(config), encoding='utf-8')
                self._revision += 1
        return self._folder

    def abrir(self, indice=-1):
        with self._lock:
            ruta = Path(self._folder if indice == -1 else self._history[int(indice)]['ruta'])
        if not ruta.exists():
            raise ValueError('El archivo o la carpeta ya no existe.')
        core.AudioFacil.abrir_ruta_sistema(ruta)

    def pantalla_completa(self):
        self._window.toggle_fullscreen()

    def limpiar_historial(self):
        with self._lock:
            self._history = []
            core.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            core.HISTORIAL_FILE.write_text('[]', encoding='utf-8')
            self._revision += 1

    def buscar(self, texto, tipo, formato, calidad='720p', subtitulos=False, idioma='Español'):
        texto = texto.strip()
        if not texto:
            raise ValueError('Escribe un enlace o el nombre de una canción.')
        if tipo not in ('descarga', 'video') or formato not in (core.FORMATOS_VIDEO if tipo == 'video' else core.FORMATOS):
            raise ValueError('Formato inválido.')
        with self._lock:
            if self._searching:
                raise ValueError('Ya hay una búsqueda en curso.')
            self._searching = True
            self._error = ''
            self._revision += 1
        def trabajo():
            try:
                self._motor.expandir_enlace(texto, formato, tipo, calidad, subtitulos, idioma)
            finally:
                with self._lock:
                    self._searching = False
                    self._revision += 1
        threading.Thread(target=trabajo, daemon=True).start()

    def importar(self, conversion=False, formato='mp3'):
        import webview
        rutas = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True)
        resultado = []
        with self._lock:
            for ruta in rutas or []:
                id = uuid.uuid4().hex
                self._files[id] = ruta
                resultado.append({'id': id, 'name': Path(ruta).name})
                if conversion:
                    if formato not in core.FORMATOS:
                        raise ValueError('Formato inválido.')
                    self._jobs.append(core.Trabajo(id=int(uuid.uuid4().int % 10**12),
                        tipo='conversion', origen=ruta, formato=formato,
                        titulo=Path(ruta).name, estado='Disponible'))
            self._revision += 1
        return resultado

    def quitar(self, ids):
        with self._lock:
            self._jobs = [j for j in self._jobs if j.id not in ids or j.estado in ('Procesando', 'Pendiente')]
            self._revision += 1

    def iniciar(self, ids):
        Path(self._folder).mkdir(parents=True, exist_ok=True)
        with self._lock:
            if self._busy:
                raise ValueError('Espera a que termine la operación actual.')
            trabajos = [j for j in self._jobs if j.id in ids]
            if not trabajos:
                raise ValueError('Selecciona al menos un archivo.')
            self._busy = True
            self._error = ''
            self._motor.carpeta = Valor(self._folder)
            for j in trabajos:
                j.estado = 'Pendiente'
            self._paused.clear()
            self._revision += 1
        def procesar():
            try:
                for j in trabajos:
                    while self._paused.is_set() and not self._closed.wait(.15):
                        pass
                    if self._closed.is_set():
                        break
                    with self._lock:
                        self._active = j.id
                        self._progress = 0
                        self._message = j.titulo
                        j.estado = 'Procesando'
                        self._motor.cancelar_actual.clear()
                        self._revision += 1
                    try:
                        if j.tipo == 'descarga':
                            self._motor.descargar(j)
                        elif j.tipo == 'video':
                            self._motor.descargar_video(j)
                        else:
                            self._motor.convertir(j)
                        if self._motor.cancelar_actual.is_set():
                            raise core.Cancelado()
                        with self._lock:
                            self._registrar(j.salida, j.tipo)
                            self._jobs.remove(j)
                            self._progress = 100
                    except Exception as error:
                        with self._lock:
                            j.estado = 'Cancelado' if self._motor.cancelar_actual.is_set() else 'Error'
                            if j.estado == 'Error':
                                self._error = str(error)
                                self._log(str(error), traceback.format_exc())
                    finally:
                        self._motor.proceso_actual = None
                        with self._lock:
                            self._revision += 1
            finally:
                with self._lock:
                    self._busy = False
                    self._active = None
                    self._message = 'Cola terminada'
                    self._revision += 1
        threading.Thread(target=procesar, daemon=True).start()

    def pausar(self):
        with self._lock:
            if self._paused.is_set():
                self._paused.clear()
            else:
                self._paused.set()
            self._revision += 1

    def cancelar(self):
        self._motor.cancelar_actual.set()
        proceso = self._motor.proceso_actual
        if proceso and proceso.poll() is None:
            proceso.terminate()

    def analizar(self, id):
        ruta = Path(self._files[id])
        stat = ruta.stat()
        clave = (str(ruta), stat.st_size, stat.st_mtime_ns)
        with self._decode_lock:
            if clave not in self._cache:
                motor = core.buscar_binario('ffmpeg')
                if not motor:
                    raise RuntimeError('Falta FFmpeg. Ejecuta el instalador incluido.')
                destino = Path(self._temp.name)/(uuid.uuid4().hex+'.wav')
                # La onda usa una copia mono ligera. La escucha usa el original.
                try:
                    duracion, picos = analizar_audio(motor, str(ruta), destino, 8000, 1)
                finally:
                    destino.unlink(missing_ok=True)
                self._cache[clave] = (destino, duracion, picos)
                while len(self._cache) > 2:
                    _, viejo = self._cache.popitem(last=False)
                    viejo[0].unlink(missing_ok=True)
            self._cache.move_to_end(clave)
            _, duracion, picos = self._cache[clave]
            return {'duration': duracion, 'peaks': picos}

    def escuchar(self, id, inicio, final):
        with self._decode_lock:
            datos = self.analizar(id)
            duracion = datos['duration']
            inicio, final = float(inicio), float(final)
            if not (math.isfinite(inicio) and math.isfinite(final) and 0 <= inicio < final <= duracion+.01):
                raise ValueError('Selecciona un tramo válido.')
            resultado = subprocess.run([core.buscar_binario('ffmpeg'), '-v', 'error', '-nostdin',
                '-ss', str(inicio), '-i', self._files[id], '-t', str(min(60, final-inicio)),
                '-vn', '-ac', '2', '-ar', '22050', '-f', 'wav', 'pipe:1'],
                capture_output=True, timeout=90,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if resultado.returncode:
                raise RuntimeError(resultado.stderr.decode(errors='replace')[-500:])
            return base64.b64encode(resultado.stdout).decode('ascii')

    def exportar(self, ids, operacion, inicio=0, final=0):
        opciones = ('Unir canciones', 'Cortar audio o video', 'Extraer audio del video',
                    'Quitar audio del video', 'Reducir voz (karaoke)', 'Normalizar volumen')
        if operacion not in opciones:
            raise ValueError('Operación inválida.')
        rutas = [self._files[id] for id in ids]
        if (operacion == 'Unir canciones' and len(rutas) < 2) or not rutas:
            raise ValueError('Agrega los archivos necesarios para esta operación.')
        if operacion != 'Unir canciones' and len(rutas) != 1:
            raise ValueError('Selecciona una canción.')
        if operacion == 'Cortar audio o video' and not (math.isfinite(float(final)) and 0 <= float(inicio) < float(final)):
            raise ValueError('El tramo seleccionado no es válido.')
        with self._lock:
            if self._busy:
                raise ValueError('Hay otra operación en proceso.')
            self._motor.editor_ajustes = (self._folder, str(inicio), str(final))
            self._motor.cancelar_actual.clear()
            self._busy = True
            self._error = ''
            self._message = 'Exportando…'
            self._progress = 0
            self._revision += 1
        def procesar():
            try:
                self._motor.procesar_edicion(operacion, rutas)
            finally:
                self._motor.proceso_actual = None
                with self._lock:
                    self._busy = False
                    self._revision += 1
        threading.Thread(target=procesar, daemon=True).start()

    def _cerrar(self):
        self._closed.set()
        self._paused.clear()
        self.cancelar()
        # No borrar mientras un análisis todavía escribe su WAV.
        if self._decode_lock.acquire(blocking=False):
            try:
                self._temp.cleanup()
            finally:
                self._decode_lock.release()

    def _plan_proyecto(self, clips, formato, cursor=None):
        from estudio_motor import comando_render
        motor = core.buscar_binario('ffmpeg')
        if not motor:
            raise RuntimeError('Falta FFmpeg. Ejecuta el instalador del programa.')
        return comando_render(motor, clips, self._files,
                              lambda ruta: Motor.obtener_duracion(motor, ruta), formato, cursor)

    def escuchar_proyecto(self, clips, cursor=0):
        with self._preview_lock:
            # Incluir datos del archivo impide reutilizar una escucha de una fuente modificada.
            fuentes = [(id, Path(self._files[id]).stat().st_mtime_ns,
                        Path(self._files[id]).stat().st_size) for id in sorted({c['source'] for c in clips})]
            clave = json.dumps([clips, cursor, fuentes], sort_keys=True)
            if self._preview_cache and self._preview_cache[0] == clave:
                return self._preview_cache[1]
            comando, total = self._plan_proyecto(clips, 'wav', cursor)
            resultado = subprocess.run(comando + ['-ar', '22050', '-f', 'wav', 'pipe:1'],
                capture_output=True, timeout=180,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if resultado.returncode:
                raise RuntimeError(resultado.stderr.decode(errors='replace')[-600:])
            datos = {'audio': base64.b64encode(resultado.stdout).decode('ascii'),
                     'duration': min(60, total-float(cursor))}
            self._preview_cache = (clave, datos)
            return datos

    def exportar_proyecto(self, clips, formato='mp3'):
        # Congelar el proyecto: los cambios posteriores no alteran una exportación activa.
        clips = json.loads(json.dumps(clips))
        with self._lock:
            if self._busy:
                raise ValueError('Espera a que termine la operación actual.')
            if formato not in ('mp3', 'wav', 'm4a'):
                raise ValueError('Formato no válido.')
            carpeta = Path(self._folder)
            carpeta.mkdir(parents=True, exist_ok=True)
            self._busy = True
            self._progress = 0
            self._error = ''
            self._message = 'Exportando secuencia con efectos…'
            self._motor.cancelar_actual.clear()
            self._revision += 1
        def renderizar():
            try:
                comando, duracion = self._plan_proyecto(clips, formato)
                destino = core.salida_unica(carpeta / f'Mi_edicion.{formato}')
                self._motor.ejecutar_ffmpeg_editor(comando + ['-progress', 'pipe:1', '-nostats', '-y', str(destino)], duracion)
                self._evento(('editor_fin', str(destino), 'Estudio: secuencia editada'))
            except core.Cancelado:
                self._evento(('editor_cancelado',))
            except Exception as error:
                self._evento(('editor_error', str(error), traceback.format_exc()))
            finally:
                self._motor.proceso_actual = None
                with self._lock:
                    self._busy = False
                    self._revision += 1
        threading.Thread(target=renderizar, daemon=True).start()


def construir_html():
    carpeta = core.ruta_recurso('web')
    html = (carpeta/'index.html').read_text(encoding='utf-8')
    html = html.replace('/*APP_CSS*/', (carpeta/'style.css').read_text(encoding='utf-8') + '\n' + (carpeta/'studio.css').read_text(encoding='utf-8'))
    html = html.replace('/*APP_JS*/', '\n'.join((carpeta/nombre).read_text(encoding='utf-8') for nombre in ('app.js', 'studio_model.js', 'studio.js')))
    from PIL import Image
    buffer = io.BytesIO()
    with Image.open(core.ruta_recurso(core.LOGO_ARCHIVO)) as imagen:
        imagen.thumbnail((320, 320))
        imagen.save(buffer, format='PNG')
    logo = base64.b64encode(buffer.getvalue()).decode('ascii')
    html = html.replace('LOGO_DATA', 'data:image/png;base64,'+logo)
    return html


def main():
    import webview
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('MarcosMorales.MoralesMusicTools')
    html = construir_html()
    api = Api()
    window = webview.create_window('Morales Music Tools 4.1', html=html, js_api=api,
                                  width=1220, height=800, min_size=(760, 560),
                                  background_color='#0b0e14', confirm_close=True)
    api._window = window
    window.events.closed += api._cerrar
    webview.start(gui='edgechromium' if sys.platform == 'win32' else None,
                  localization={'global.quitConfirmation': '¿Cerrar Morales Music Tools? Se cancelará la operación actual.'},
                  icon=str(core.ruta_recurso(core.ICONO_ARCHIVO if sys.platform == 'win32' else core.LOGO_ARCHIVO)))


if __name__ == '__main__':
    main()

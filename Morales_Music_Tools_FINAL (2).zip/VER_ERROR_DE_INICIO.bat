@echo off
if exist "%USERPROFILE%\.morales_music_tools\inicio_error.txt" (
    start "" notepad.exe "%USERPROFILE%\.morales_music_tools\inicio_error.txt"
) else (
    echo Primero intenta abrir el programa para generar el registro.
    pause
)

"""Renderiza una secuencia de fragmentos con los mismos efectos en escucha y exportación."""
import math
from pathlib import Path


def numero(valor, nombre):
    try:
        resultado = float(valor)
    except (ValueError, TypeError):
        raise ValueError(f'{nombre}: escribe un número válido.')
    if not math.isfinite(resultado):
        raise ValueError(f'{nombre}: el valor no es válido.')
    return resultado


def crear_plan(clips, archivos, duracion_archivo):
    if not isinstance(clips, list) or not 1 <= len(clips) <= 200:
        raise ValueError('Agrega entre 1 y 200 fragmentos a la línea de tiempo.')
    entradas, filtros, etiquetas = [], [], []
    total = 0.0
    duraciones = {}
    for i, clip in enumerate(clips):
        fuente = clip.get('source')
        if fuente not in archivos:
            raise ValueError('Un archivo del proyecto ya no está disponible. Impórtalo nuevamente.')
        ruta = Path(archivos[fuente])
        if not ruta.is_file():
            raise ValueError(f'No se encuentra {ruta.name}.')
        if fuente not in duraciones:
            duraciones[fuente] = duracion_archivo(ruta)
        inicio = numero(clip.get('in'), 'Inicio')
        final = numero(clip.get('out'), 'Final')
        if not 0 <= inicio < final <= duraciones[fuente] + .025:
            raise ValueError(f'El recorte de {ruta.name} está fuera del archivo.')
        final = min(final, duraciones[fuente])
        duracion = final - inicio
        if duracion < .01:
            raise ValueError('Cada fragmento debe durar al menos 0.01 segundos.')
        volumen = numero(clip.get('volume', 1), 'Volumen')
        if not 0 <= volumen <= 2:
            raise ValueError('El volumen debe estar entre 0 y 200 %.')
        entrada = numero(clip.get('fadeIn', 0), 'Entrada suave')
        salida = numero(clip.get('fadeOut', 0), 'Salida suave')
        if entrada < 0 or salida < 0:
            raise ValueError('La duración del efecto no puede ser negativa.')
        entrada, salida = min(entrada, duracion), min(salida, duracion)
        if clip.get('muted'):
            volumen = 0
        # Seek por entrada: no decodifica el archivo entero para un recorte corto.
        entradas += ['-ss', str(inicio), '-t', str(duracion), '-i', str(ruta)]
        cadena = f'[{i}:a:0]atrim=duration={duracion},asetpts=PTS-STARTPTS,aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume={volumen}'
        if entrada:
            cadena += f',afade=t=in:st=0:d={entrada}'
        if salida:
            cadena += f',afade=t=out:st={duracion-salida}:d={salida}'
        cadena += f'[clip{i}]'
        filtros.append(cadena)
        etiquetas.append(f'[clip{i}]')
        total += duracion
    filtros.append(''.join(etiquetas) + f'concat=n={len(clips)}:v=0:a=1[mezcla]')
    return entradas, filtros, total


def comando_render(motor, clips, archivos, duracion_archivo, formato='mp3', cursor=None):
    entradas, filtros, total = crear_plan(clips, archivos, duracion_archivo)
    comando = [motor, '-hide_banner', '-loglevel', 'error', '-nostdin', *entradas]
    etiqueta = '[mezcla]'
    if cursor is not None:
        cursor = numero(cursor, 'Cursor')
        if not 0 <= cursor < total:
            raise ValueError('Coloca el cursor dentro de la secuencia.')
        # Recorta después de los efectos: escucha y exportación comparten el mismo resultado.
        filtros.append(f'[mezcla]atrim=start={cursor}:end={min(total,cursor+60)},asetpts=PTS-STARTPTS[escucha]')
        etiqueta = '[escucha]'
    comando += ['-filter_complex', ';'.join(filtros), '-map', etiqueta, '-vn']
    codecs = {'mp3': ['-c:a', 'libmp3lame', '-q:a', '2'],
              'wav': ['-c:a', 'pcm_s16le'], 'm4a': ['-c:a', 'aac', '-b:a', '256k']}
    if formato not in codecs:
        raise ValueError('Elige MP3, WAV o M4A.')
    comando += codecs[formato]
    return comando, total

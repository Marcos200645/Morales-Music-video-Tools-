@echo off
setlocal
title Actualizar Morales Music Tools
cd /d "%~dp0"
color 0A

echo ==================================================
echo       ACTUALIZAR MORALES MUSIC TOOLS
echo ==================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado o no esta en PATH.
    pause
    exit /b 1
)

echo Actualizando motor de descargas y componentes...
call INSTALAR_Morales_Music_Tools.bat /auto
if errorlevel 1 (
    echo.
    echo ERROR: No se pudieron actualizar los componentes.
    pause
    exit /b 1
)

echo.
echo Componentes actualizados correctamente.
echo Ahora se volvera a crear el ejecutable con el motor nuevo.
echo.
call CREAR_EXE_Morales_Music_Tools.bat

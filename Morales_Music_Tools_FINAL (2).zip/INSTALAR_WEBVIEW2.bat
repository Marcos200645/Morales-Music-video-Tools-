@echo off
echo Se abrira la pagina oficial de Microsoft.
echo Descarga e instala Evergreen Bootstrapper o Standalone Installer x64.
start "" "https://developer.microsoft.com/microsoft-edge/webview2/"
pause

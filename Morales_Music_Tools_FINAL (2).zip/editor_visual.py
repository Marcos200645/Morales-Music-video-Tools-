"""Editor de audio con forma de onda, selección y escucha local."""
import array
import math
import queue
import subprocess
import tempfile
import threading
import time
import wave
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


def analizar_audio(motor, archivo, destino, frecuencia=22050, canales=2):
    proceso = subprocess.run(
        [motor, '-v', 'error', '-nostdin', '-y', '-i', archivo, '-vn',
         '-ac', str(canales), '-ar', str(frecuencia), '-c:a', 'pcm_s16le', str(destino)],
        capture_output=True, timeout=600,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if proceso.returncode:
        raise RuntimeError(proceso.stderr.decode(errors='replace')[-600:])
    with wave.open(str(destino), 'rb') as audio:
        duracion = audio.getnframes() / audio.getframerate()
        bloque = max(1, math.ceil(audio.getnframes() / 2500))
        picos = []
        while datos := audio.readframes(bloque):
            valores = array.array('h', datos)
            import sys
            if sys.byteorder != 'little':
                valores.byteswap()
            picos.append(max(map(abs, valores), default=0) / 32768)
    if duracion <= 0:
        raise ValueError('El archivo no contiene audio.')
    return duracion, picos


class EditorVisual(ttk.Frame):
    def __init__(self, padre, app, buscar_motor):
        super().__init__(padre, padding=10)
        self.pack(fill='both', expand=True)
        self.app, self.buscar_motor = app, buscar_motor
        self.archivos, self.picos = [], []
        self.duracion = self.inicio = self.final = self.cursor = 0.0
        self.zoom = 1
        self.token = 0
        self.resultados = queue.Queue()
        self.temporal = tempfile.TemporaryDirectory(prefix='mmt_editor_')
        self.wav = None
        self.canal = None
        self.cerrado = False
        self.modo = None
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        barra = ttk.Frame(self)
        barra.grid(row=0, column=0, sticky='ew')
        ttk.Label(barra, text='ESTUDIO DE AUDIO', style='Title.TLabel').pack(side='left')
        ttk.Button(barra, text='Importar canciones', command=self.importar).pack(side='right')
        self.titulo = tk.StringVar(value='Importa una canción para ver su forma de onda')
        ttk.Label(self, textvariable=self.titulo).grid(row=1, column=0, sticky='w', pady=6)
        cuerpo = ttk.Panedwindow(self, orient='horizontal')
        cuerpo.grid(row=2, column=0, sticky='nsew')
        biblioteca = ttk.Frame(cuerpo, width=190)
        cuerpo.add(biblioteca, weight=1)
        ttk.Label(biblioteca, text='ARCHIVOS / ORDEN DE UNIÓN').pack(anchor='w')
        self.lista = tk.Listbox(biblioteca, bg='#10161f', fg='white',
                               selectbackground='#238636', exportselection=False, height=4)
        self.lista.pack(fill='both', expand=True, pady=6)
        self.lista.bind('<<ListboxSelect>>', self.seleccionar)
        ordenar = ttk.Frame(biblioteca)
        ordenar.pack(fill='x')
        for texto, accion in [('↑', lambda: self.mover(-1)), ('↓', lambda: self.mover(1)),
                              ('Quitar', self.quitar)]:
            ttk.Button(ordenar, text=texto, width=6, command=accion).pack(side='left')
        pista = ttk.Frame(cuerpo)
        cuerpo.add(pista, weight=4)
        self.canvas = tk.Canvas(pista, bg='#0a1018', height=140, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        scroll = ttk.Scrollbar(pista, orient='horizontal', command=self.canvas.xview)
        scroll.pack(fill='x')
        self.canvas.configure(xscrollcommand=scroll.set)
        self.canvas.bind('<Configure>', lambda e: self.dibujar())
        self.canvas.bind('<Button-1>', self.pulsar)
        self.canvas.bind('<B1-Motion>', self.arrastrar)
        self.canvas.bind('<ButtonRelease-1>', lambda e: setattr(self, 'modo', None))
        controles = ttk.Frame(self)
        controles.grid(row=3, column=0, sticky='ew', pady=6)
        for texto, accion in [('▶ Escuchar', self.reproducir), ('■ Detener', self.detener),
                              ('Inicio aquí', lambda: self.marcar(True)),
                              ('Final aquí', lambda: self.marcar(False)),
                              ('− Zoom', lambda: self.ampliar(0.5)),
                              ('+ Zoom', lambda: self.ampliar(2))]:
            ttk.Button(controles, text=texto, command=accion).pack(side='left', padx=2)
        self.info = tk.StringVar(value='Arrastra los bordes verdes para recortar. Haz clic para mover el cursor.')
        ttk.Label(self, textvariable=self.info).grid(row=4, column=0, sticky='w')
        acciones = ttk.Frame(self)
        acciones.grid(row=5, column=0, sticky='ew', pady=6)
        ttk.Label(acciones, text='Exportar:').pack(side='left')
        app.editor_operacion.set('Cortar audio o video')
        ttk.Combobox(acciones, textvariable=app.editor_operacion, state='readonly', width=25,
                     values=('Cortar audio o video', 'Unir canciones', 'Normalizar volumen',
                             'Reducir voz (karaoke)', 'Extraer audio del video',
                             'Quitar audio del video')).pack(side='left', padx=6)
        app.boton_editor = ttk.Button(acciones, text='Exportar archivo', style='Accent.TButton', command=self.exportar)
        app.boton_editor.pack(side='left')
        ttk.Button(acciones, text='Cancelar exportación', command=app.cancelar).pack(side='left', padx=6)
        ttk.Button(acciones, text='Carpeta…', command=self.carpeta).pack(side='left')
        app.progreso_editor = ttk.Progressbar(self, maximum=100)
        app.progreso_editor.grid(row=6, column=0, sticky='ew')
        ttk.Label(self, textvariable=app.editor_estado).grid(row=7, column=0, sticky='w')
        ttk.Label(self, text='Escucha original: hasta 60 s. Unión: archivos completos en orden. Los efectos se aplican al exportar.').grid(row=8, column=0, sticky='w')
        self.after(80, self.actualizar)
        self.bind('<Destroy>', self.cerrar)

    def carpeta(self):
        ruta = filedialog.askdirectory(parent=self, title='Carpeta de exportación')
        if ruta:
            self.app.carpeta.set(ruta)

    def importar(self):
        rutas = filedialog.askopenfilenames(parent=self, title='Importar audio o video')
        for ruta in rutas:
            if ruta not in self.archivos:
                self.archivos.append(ruta)
                self.lista.insert('end', Path(ruta).name)
        if rutas and not self.lista.curselection():
            self.lista.selection_set(0)
            self.seleccionar()

    def seleccionar(self, evento=None):
        seleccion = self.lista.curselection()
        if not seleccion:
            return
        self.detener()
        self.token += 1
        token = self.token
        archivo = self.archivos[seleccion[0]]
        self.wav = None
        self.picos = []
        self.duracion = self.inicio = self.final = self.cursor = 0
        self.zoom = 1
        self.titulo.set(Path(archivo).name)
        self.info.set('Preparando forma de onda…')
        self.dibujar()
        motor = self.buscar_motor('ffmpeg')
        destino = Path(self.temporal.name) / f'{token}.wav'
        def cargar():
            try:
                if not motor:
                    raise RuntimeError('Falta FFmpeg. Ejecuta el instalador incluido.')
                duracion, picos = analizar_audio(motor, archivo, destino)
                self.resultados.put((token, destino, duracion, picos, None))
            except Exception as error:
                self.resultados.put((token, destino, 0, [], str(error)))
        threading.Thread(target=cargar, daemon=True).start()

    def mover(self, paso):
        seleccion = self.lista.curselection()
        if not seleccion:
            return
        i, j = seleccion[0], seleccion[0] + paso
        if 0 <= j < len(self.archivos):
            self.archivos[i], self.archivos[j] = self.archivos[j], self.archivos[i]
            self.lista.delete(0, 'end')
            for ruta in self.archivos:
                self.lista.insert('end', Path(ruta).name)
            self.lista.selection_set(j)

    def quitar(self):
        seleccion = self.lista.curselection()
        if seleccion:
            self.detener()
            self.token += 1
            del self.archivos[seleccion[0]]
            self.lista.delete(seleccion[0])
            self.wav = None
            self.picos = []
            self.duracion = 0
            self.dibujar()
            if self.archivos:
                self.lista.selection_set(0)
                self.seleccionar()
            else:
                self.titulo.set('Importa una canción')

    def ancho(self):
        return max(200, self.canvas.winfo_width() - 40) * self.zoom

    def x(self, segundo):
        return 20 + segundo / max(self.duracion, .001) * self.ancho()

    def tiempo(self, evento):
        return min(self.duracion, max(0, (self.canvas.canvasx(evento.x) - 20) / self.ancho() * self.duracion))

    def dibujar(self):
        c = self.canvas
        c.delete('all')
        ancho, alto = self.ancho(), max(100, c.winfo_height())
        c.configure(scrollregion=(0, 0, ancho + 40, alto))
        if not self.picos:
            c.create_text(30, 55, text='La forma de onda aparecerá aquí', fill='#94a3b8', anchor='w')
            return
        c.create_rectangle(self.x(self.inicio), 32, self.x(self.final), alto-15, fill='#123d32', outline='')
        for i in range(11):
            x = 20 + ancho * i / 10
            c.create_text(x, 14, text=f'{self.duracion*i/10:.1f}s', fill='#94a3b8')
        centro = (alto+32)/2
        for i, pico in enumerate(self.picos):
            x = 20 + i / len(self.picos) * ancho
            h = max(1, pico*(alto-65)/2)
            c.create_line(x, centro-h, x, centro+h, fill='#32d9b4')
        for tiempo, etiqueta in ((self.inicio, 'IN'), (self.final, 'OUT')):
            x = self.x(tiempo)
            c.create_line(x, 30, x, alto, fill='#a3ff61', width=4)
            c.create_text(x, 40, text=etiqueta, fill='white', anchor='n')
        c.create_line(self.x(self.cursor), 22, self.x(self.cursor), alto, fill='#ffffff', width=2)
        self.info.set(f'Inicio {self.inicio:.2f}s  ·  Final {self.final:.2f}s  ·  Selección {self.final-self.inicio:.2f}s  ·  Cursor {self.cursor:.2f}s')

    def pulsar(self, evento):
        self.detener()
        x = self.canvas.canvasx(evento.x)
        self.modo = ('inicio' if abs(x-self.x(self.inicio)) < 12 else
                     'final' if abs(x-self.x(self.final)) < 12 else 'cursor')
        self.arrastrar(evento)

    def arrastrar(self, evento):
        if not self.duracion:
            return
        t = self.tiempo(evento)
        if self.modo == 'inicio':
            self.inicio = min(t, max(0, self.final-.01))
        elif self.modo == 'final':
            self.final = max(t, self.inicio+.01)
        else:
            self.cursor = t
        self.dibujar()

    def marcar(self, inicio):
        if inicio:
            self.inicio = min(self.cursor, max(0, self.final-.01))
        else:
            self.final = min(self.duracion, max(self.cursor, self.inicio+.01))
        self.dibujar()

    def ampliar(self, factor):
        self.zoom = max(1, min(16, self.zoom*factor))
        self.dibujar()

    def reproducir(self):
        if not self.wav:
            return
        self.detener()
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=2, allowedchanges=0)
            inicio = self.cursor if self.inicio <= self.cursor < self.final else self.inicio
            with wave.open(str(self.wav), 'rb') as audio:
                audio.setpos(int(inicio*22050))
                datos = audio.readframes(int(min(60, self.final-inicio)*22050))
            self.sonido = pygame.mixer.Sound(buffer=datos)
            self.canal = self.sonido.play()
            self.reloj, self.desde = time.monotonic(), inicio
        except Exception as error:
            messagebox.showerror('No se pudo reproducir', f'{error}\nEjecuta INSTALAR_Morales_Music_Tools.bat para instalar la reproducción.', parent=self)

    def detener(self):
        if self.canal:
            self.canal.stop()
        self.canal = None

    def exportar(self):
        seleccion = self.lista.curselection()
        if not seleccion:
            return
        operacion = self.app.editor_operacion.get()
        if operacion == 'Cortar audio o video' and not self.wav:
            messagebox.showinfo('Espera', 'Espera a que termine de cargar el audio.', parent=self)
            return
        self.app.editor_archivos = list(self.archivos) if operacion == 'Unir canciones' else [self.archivos[seleccion[0]]]
        self.app.editor_inicio.set(str(self.inicio))
        self.app.editor_final.set(str(self.final))
        self.app.iniciar_edicion()

    def actualizar(self):
        if self.cerrado:
            return
        while not self.resultados.empty():
            token, destino, duracion, picos, error = self.resultados.get_nowait()
            if token != self.token:
                destino.unlink(missing_ok=True)
                continue
            if error:
                self.info.set('No se pudo preparar el audio')
                messagebox.showerror('Audio', error, parent=self)
            else:
                self.wav, self.duracion, self.final, self.picos = destino, duracion, duracion, picos
                self.dibujar()
        if self.canal:
            self.cursor = min(self.final, self.desde + time.monotonic()-self.reloj)
            self.dibujar()
            if not self.canal.get_busy():
                self.canal = None
        self.after(80, self.actualizar)

    def cerrar(self, evento):
        if evento.widget == self:
            self.cerrado = True
            self.detener()
            try:
                self.temporal.cleanup()
            except OSError:
                pass

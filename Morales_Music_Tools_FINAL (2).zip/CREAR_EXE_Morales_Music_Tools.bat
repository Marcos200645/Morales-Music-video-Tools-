@echo off
setlocal
title Crear EXE - Morales Music Tools
cd /d "%~dp0"
color 0A

echo ==================================================
echo       CREAR MORALES MUSIC TOOLS.EXE
echo ==================================================
echo.

call INSTALAR_Morales_Music_Tools.bat /auto
if errorlevel 1 goto :error
echo [1/4] Instalando herramientas necesarias...
".venv\Scripts\python.exe" -m pip install --upgrade pyinstaller
if errorlevel 1 goto :error

echo [2/4] Preparando el motor FFmpeg integrado...
if not exist "Morales_Music_Tools_Logo.png" goto :error
if not exist "Morales_Music_Tools.ico" goto :error
if not exist "web\index.html" goto :error
echo [3/4] Construyendo el ejecutable. Esto puede tardar varios minutos...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed ^
 --name "Morales_Music_Tools" ^
 --icon "Morales_Music_Tools.ico" ^
 --add-data "Morales_Music_Tools_Logo.png;." ^
 --add-data "Morales_Music_Tools.ico;." ^
 --add-data "web;web" ^
 --collect-all yt_dlp ^
 --collect-all imageio_ffmpeg ^
 --hidden-import PIL.ImageTk ^
 --collect-all webview ^
 --exclude-module PySide6 --exclude-module PyQt5 --exclude-module PyQt6 ^
 "Morales_Music_Tools.py"
if errorlevel 1 goto :error
echo.
echo [4/4] PROCESO TERMINADO CORRECTAMENTE
echo.
echo El programa se creo en:
echo %CD%\dist\Morales_Music_Tools\Morales_Music_Tools.exe
echo Copia TODA la carpeta dist\Morales_Music_Tools a la otra computadora.
echo Esto evita extraer FFmpeg en cada apertura. Windows necesita WebView2 Runtime.
echo.
start "" "%CD%\dist"
pause
exit /b 0

:error
echo.
echo ERROR: No se pudo crear el ejecutable.
echo Revise los mensajes mostrados arriba.
pause
exit /b 1

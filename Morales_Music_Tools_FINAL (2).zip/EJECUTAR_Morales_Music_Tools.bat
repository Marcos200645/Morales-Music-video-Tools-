@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call INSTALAR_Morales_Music_Tools.bat /auto
    if errorlevel 1 (
        pause
        exit /b 1
    )
)
".venv\Scripts\python.exe" Morales_Music_Tools.py
if errorlevel 1 pause

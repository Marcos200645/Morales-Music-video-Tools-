@echo off
setlocal
title Instalar Morales Music Tools
cd /d "%~dp0"
color 0A
echo ==================================================
echo        INSTALAR MORALES MUSIC TOOLS
echo ==================================================
echo.
where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado.
    echo Descarguelo desde https://www.python.org/downloads/
    echo y marque la opcion Add Python to PATH.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade -r requirements_Morales_Music_Tools.txt
if errorlevel 1 (
    echo No se pudieron instalar los componentes. Revise su conexion.
    pause
    exit /b 1
)
echo.
echo Motor FFmpeg instalado dentro del programa.
echo Instalacion terminada.
echo Si falta WebView2, ejecuta INSTALAR_WEBVIEW2.bat.
if /I not "%~1"=="/auto" pause
exit /b 0

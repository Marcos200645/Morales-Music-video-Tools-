'use strict';
const $=id=>document.getElementById(id);
const logo=$('thumbnail').src;
let page='editor';
let state={jobs:[],history:[],busy:false},revision=-1,checked=new Set(),loadToken=0,playToken=0;
let audioURL=null,playFrom=0,drag=null,toastTimer;
const api=(method,...args)=>window.pywebview.api[method](...args);
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const seconds=s=>`${String(Math.floor(s/60)).padStart(2,'0')}:${(s%60).toFixed(2).padStart(5,'0')}`;
function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,4500);}
function bind(id,action){$(id).addEventListener('click',async()=>{try{await action();}catch(e){toast(e.message||String(e));}});}
function currentType(){return {audio:'descarga',video:'video',convert:'conversion'}[page];}
function showPage(next){
  page=next;document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const titles={editor:'Estudio de audio',audio:'Descargar música',video:'Descargar videos',convert:'Convertir archivos',history:'Tu historial'};
  $('pageTitle').textContent=titles[page];
  $(page==='editor'||page==='history'?page:'downloads').classList.add('active');
  if(['audio','video','convert'].includes(page)){
    $('qualityLabel').hidden=page!=='video';$('subsLabel').hidden=page!=='video';
    $('query').hidden=page==='convert';$('search').hidden=page==='convert';$('importConvert').hidden=page!=='convert';
    $('searchLabel').textContent=page==='convert'?'Elige archivos de tu equipo para convertir':page==='video'?'Enlace de video o playlist':'Enlace, playlist o nombre de canción';
    $('format').replaceChildren(...(page==='video'?['mp4','mkv','webm']:['mp3','m4a','wav','flac','ogg','opus','aac']).map(f=>new Option(f.toUpperCase(),f)));
    $('downloadSelected').textContent=page==='convert'?'Convertir selección':'Descargar selección';
    renderJobs();
  }
  if(page==='editor')requestAnimationFrame(()=>window.Studio?.render());
}
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.addEventListener('keydown',e=>{if(e.key==='F11'){e.preventDefault();api('pantalla_completa').catch(error=>toast(error.message));}});
bind('cancelExport',()=>api('cancelar'));bind('folderButton',()=>api('carpeta'));bind('openFolder',()=>api('abrir',-1));
bind('search',async()=>{await api('buscar',$('query').value,currentType(),$('format').value,$('quality').value,!!$('subs').value,$('subs').value||'Español');});
$('query').onkeydown=e=>{if(e.key==='Enter')$('search').click();};
bind('importConvert',()=>api('importar',true,$('format').value));
function renderJobs(){
  const jobs=state.jobs.filter(j=>j.tipo===currentType());
  $('jobs').innerHTML=jobs.map(j=>`<tr><td><input type="checkbox" aria-label="Seleccionar ${escapeHTML(j.titulo)}" data-id="${j.id}" ${checked.has(j.id)?'checked':''}></td><td title="${escapeHTML(j.titulo)}">${escapeHTML(j.titulo)}</td><td>${escapeHTML(j.estado)}</td><td>${Math.round(j.progreso)}%</td></tr>`).join('');
  $('jobs').querySelectorAll('input').forEach(input=>input.onchange=()=>{const id=Number(input.dataset.id);input.checked?checked.add(id):checked.delete(id);});
  $('queueEmpty').hidden=jobs.length>0;
  const active=jobs.find(j=>j.id===state.active),next=jobs.find(j=>j.estado==='Pendiente'&&j.id!==state.active);
  const image=active?.miniatura;const src=image&&/^https:\/\//.test(image)?image:logo;if($('thumbnail').getAttribute('src')!==src)$('thumbnail').src=src;
  $('nowTitle').textContent=active?.titulo||'Sin archivo en proceso';$('nextTitle').textContent='Siguiente: '+(next?.titulo||'ninguna');
  $('speed').textContent=active?`${active.velocidad||''} ${active.eta?'· '+active.eta+' restantes':''}`:'Sin límite artificial de velocidad';
}
$('thumbnail').onerror=()=>{$('thumbnail').src=logo;};
bind('selectAll',()=>{const jobs=state.jobs.filter(j=>j.tipo===currentType());const all=jobs.every(j=>checked.has(j.id));jobs.forEach(j=>all?checked.delete(j.id):checked.add(j.id));renderJobs();});
bind('downloadSelected',()=>api('iniciar',state.jobs.filter(j=>j.tipo===currentType()&&checked.has(j.id)).map(j=>j.id)));
bind('downloadAll',()=>api('iniciar',state.jobs.filter(j=>j.tipo===currentType()).map(j=>j.id)));
bind('removeJobs',()=>api('quitar',Array.from(checked)));bind('pause',()=>api('pausar'));bind('cancel',()=>api('cancelar'));
bind('clearHistory',async()=>{if(confirm('¿Limpiar el historial? Tus archivos se conservarán.'))await api('limpiar_historial');});
let historySignature='';
function renderState(){
  $('openFolder').textContent=state.folder;$('openFolder').title=state.folder;
  $('status').textContent=state.searching?'Buscando archivos…':state.message;
  $('progress').value=state.progress;$('percentage').textContent=Math.round(state.progress)+'%';
  $('error').hidden=!state.error;$('error').textContent=state.error||'';
  $('search').disabled=state.searching;
  for(const id of ['export','downloadSelected','downloadAll'])$(id).disabled=state.busy;
  $('pause').textContent=state.paused?'Continuar cola':'Pausar cola';
  if(['audio','video','convert'].includes(page))renderJobs();
  const signature=JSON.stringify(state.history);
  if(signature!==historySignature){historySignature=signature;$('historyRows').innerHTML=state.history.map((h,i)=>`<tr><td>${escapeHTML(h.fecha)}</td><td title="${escapeHTML(h.ruta)}">${escapeHTML(h.nombre)}</td><td>${escapeHTML(h.tipo||h.operacion||'')}</td><td><button data-history="${i}">Abrir ↗</button></td></tr>`).join('');$('historyRows').querySelectorAll('button').forEach(b=>b.onclick=()=>api('abrir',Number(b.dataset.history)).catch(e=>toast(e.message)));}
}
async function poll(){try{const next=await api('estado',revision);if(next){state=next;revision=state.revision;renderState();}}catch(e){$('status').textContent='No se pudo actualizar el estado';}setTimeout(poll,450);}
window.addEventListener('pywebviewready',()=>{poll();setTimeout(()=>{$('splash').style.opacity='0';setTimeout(()=>$('splash').hidden=true,350);},Math.max(0,850-performance.now()));});
// Vista previa sin puente: muestra únicamente el diseño, no simula descargas.
if(location.search.includes('preview')){setTimeout(()=>$('splash').hidden=true,400);$('status').textContent='Vista previa del diseño';}

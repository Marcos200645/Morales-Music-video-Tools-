(function(){
  'use strict';
  const model=new window.StudioModel(), sources=new Map(), audio=document.getElementById('player');
  let cursor=0, zoom=1, playingFrom=0, previewLength=0, blobURL=null, generation=0, raf=0, trimming=null, dragging=null;
  let loading=0;
  const total=()=>model.total();
  const source=clip=>sources.get(clip.source);
  const px=()=>Math.max(300,$('studioScroll').clientWidth)*zoom/Math.max(total(),1);
  function stop(reset=false){generation++;audio.pause();audio.removeAttribute('src');if(blobURL){URL.revokeObjectURL(blobURL);blobURL=null;}cancelAnimationFrame(raf);$('play').textContent='▶';$('previewStatus').textContent='Escucha con tus cambios';if(reset)cursor=0;renderCursor();}
  function change(action){stop();action();cursor=Math.min(cursor,total());render();}
  function renderCursor(){const x=cursor*px();$('studioCursor').style.left=x+'px';$('clock').textContent=seconds(cursor);}
  function renderLibrary(){
    $('fileCount').textContent=sources.size;
    $('files').innerHTML=Array.from(sources.values()).map(s=>`<div class="studio-file"><span class="file-icon">♫</span><span title="${escapeHTML(s.name)}">${escapeHTML(s.name)}</span><button data-source="${s.id}" title="Agregar a la secuencia" ${s.loading?'disabled':''}>${s.loading?'…':'＋'}</button></div>`).join('')||'<p class="hint">Tus archivos aparecerán aquí.</p>';
    $('files').querySelectorAll('button').forEach(button=>button.onclick=()=>addSource(button.dataset.source).catch(e=>toast(e.message)));
    const previous=$('toolSource').value;
    $('toolSource').replaceChildren(...Array.from(sources.values()).map(s=>new Option(s.name,s.id)));
    if(sources.has(previous))$('toolSource').value=previous;
  }
  async function analyze(id){const s=sources.get(id);if(s.data)return s.data;if(s.promise)return s.promise;s.loading=true;renderLibrary();s.promise=api('analizar',id).then(data=>(s.data=data)).finally(()=>{s.loading=false;s.promise=null;renderLibrary();});return s.promise;}
  async function addSource(id){const s=sources.get(id);if(!s)return;loading++;$('previewStatus').textContent='Preparando forma de onda…';try{const data=await analyze(id);change(()=>model.add(id,s.name,data.duration));}finally{loading--;$('previewStatus').textContent=loading?'Preparando forma de onda…':'Escucha con tus cambios';}}
  function inspector(){
    const c=model.active();$('clipSettings').disabled=!c;
    $('selectedName').textContent=c?c.name:'Ninguno';$('clipDuration').textContent=c?seconds(c.out-c.in):'—';
    if(c){$('clipIn').value=c.in.toFixed(2);$('clipOut').value=c.out.toFixed(2);$('clipVolume').value=Math.round(c.volume*100);$('volumeText').textContent=Math.round(c.volume*100)+' %';$('clipMute').checked=c.muted;$('fadeIn').value=c.fadeIn.toFixed(2);$('fadeOut').value=c.fadeOut.toFixed(2);}
    for(const id of ['split','duplicate','deleteClip','moveLeft','moveRight'])$(id).disabled=!c;
    $('undo').disabled=!model.undoStack.length;$('redo').disabled=!model.redoStack.length;
    $('clipCount').textContent=model.clips.length+' FRAGMENTOS';$('projectDuration').textContent=' / '+seconds(total());
  }
  function paint(canvas,c){
    const data=source(c)?.data;if(!data)return;
    const width=Math.min(4096,Math.max(2,canvas.clientWidth)),height=canvas.clientHeight||100;
    canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');ctx.strokeStyle=c.muted?'#668279':'#a1ebd7';ctx.lineWidth=1;
    const peaks=data.peaks,a=c.in/data.duration*peaks.length,b=c.out/data.duration*peaks.length;
    ctx.beginPath();for(let x=0;x<width;x+=2){const i=Math.min(peaks.length-1,Math.floor(a+(b-a)*x/width)),v=peaks[i]||0;const h=Math.max(1,Math.min(1,v*c.volume)*height*.43);ctx.moveTo(x,height/2-h);ctx.lineTo(x,height/2+h);}ctx.stroke();
  }
  function render(){
    const scale=px(),width=Math.max(300,$('studioScroll').clientWidth)*zoom;
    $('studioTrack').style.width=width+'px';$('zoomText').textContent=zoom+'×';
    $('studioEmpty').hidden=!!model.clips.length;$('studioCursor').hidden=!model.clips.length;
    let offset=0;
    $('clipLane').innerHTML=model.clips.map((c,index)=>{const duration=c.out-c.in,left=offset*scale;offset+=duration;return `<div class="studio-clip ${c.id===model.selected?'selected':''} ${c.muted?'muted':''}" data-clip="${c.id}" style="left:${left}px;width:${duration*scale}px"><div class="clip-title" draggable="true" title="Arrastra para cambiar el orden"><span>${index+1} · ${escapeHTML(c.name)}</span></div><canvas class="clip-wave"></canvas><div class="fade-shape in" style="width:${c.fadeIn/duration*100}%"></div><div class="fade-shape out" style="width:${c.fadeOut/duration*100}%"></div><div class="clip-trim left" data-edge="in" title="Recortar inicio"></div><div class="clip-trim right" data-edge="out" title="Recortar final"></div></div>`;}).join('');
    $('studioRuler').innerHTML=Array.from({length:Math.max(2,Math.ceil(width/90))},(_,i)=>`<span style="left:${i*90}px">${seconds(i*90/scale)}</span>`).join('');
    $('clipLane').querySelectorAll('.studio-clip').forEach(el=>{
      const c=model.clips.find(c=>c.id===el.dataset.clip);paint(el.querySelector('canvas'),c);
      el.querySelector('.clip-title').ondragstart=e=>{model.selected=c.id;dragging=c.id;e.dataTransfer.setData('text/plain',c.id);e.dataTransfer.effectAllowed='move';inspector();};
      el.ondragover=e=>{e.preventDefault();el.classList.add('studio-dragover');};
      el.ondragleave=()=>el.classList.remove('studio-dragover');
      el.ondrop=e=>{e.preventDefault();e.stopPropagation();const id=dragging;if(!id)return;change(()=>model.move(id,model.clips.indexOf(c)));dragging=null;};
      el.ondragend=()=>{dragging=null;render();};
    });
    inspector();renderCursor();
  }
  function setCursor(e){const bounds=$('studioTrack').getBoundingClientRect();cursor=Math.max(0,Math.min(total(),(e.clientX-bounds.left)/px()));renderCursor();}
  $('studioRuler').onpointerdown=e=>{stop();setCursor(e);};
  $('clipLane').onpointerdown=e=>{
    const el=e.target.closest('.studio-clip');if(!el)return;
    model.selected=el.dataset.clip;inspector();
    $('clipLane').querySelectorAll('.studio-clip').forEach(n=>n.classList.toggle('selected',n===el));
    if(e.target.dataset.edge){
      stop();const c=model.active();trimming={x:e.clientX,edge:e.target.dataset.edge,initial:{...c},before:model.snapshot(),scale:px(),changed:false};
      $('studioScroll').setPointerCapture(e.pointerId);e.preventDefault();
    }else if(!e.target.closest('.clip-title')){stop();setCursor(e);}
  };
  $('studioScroll').onpointermove=e=>{
    if(!trimming)return;const d=(e.clientX-trimming.x)/trimming.scale,c=trimming.initial;
    const values=trimming.edge==='in'?{in:Math.max(0,Math.min(c.out-.011,c.in+d))}:{out:Math.min(c.sourceDuration,Math.max(c.in+.011,c.out+d))};
    model.edit(values,false);trimming.changed=true;cursor=Math.min(cursor,total());render();
  };
  function finishTrim(){if(trimming){if(trimming.changed)model.remember(trimming.before);trimming=null;render();}}
  $('studioScroll').onpointerup=finishTrim;$('studioScroll').onpointercancel=finishTrim;
  $('clipLane').ondragover=e=>e.preventDefault();
  $('clipLane').ondrop=e=>{e.preventDefault();if(dragging){change(()=>model.move(dragging,model.clips.length-1));dragging=null;}};
  bind('importFiles',async()=>{const added=await api('importar',false);added.forEach(s=>sources.set(s.id,{...s,data:null}));renderLibrary();if(added.length&&!model.clips.length)await addSource(added[0].id);});
  bind('undo',()=>change(()=>model.undo()));bind('redo',()=>change(()=>model.redo()));
  bind('split',()=>change(()=>model.split(cursor)));bind('deleteClip',()=>change(()=>model.remove()));bind('duplicate',()=>change(()=>model.duplicate()));
  bind('moveLeft',()=>change(()=>model.move(model.selected,model.clips.findIndex(c=>c.id===model.selected)-1)));
  bind('moveRight',()=>change(()=>model.move(model.selected,model.clips.findIndex(c=>c.id===model.selected)+1)));
  bind('zoomIn',()=>{zoom=Math.min(16,zoom*2);render();});bind('zoomOut',()=>{zoom=Math.max(1,zoom/2);render();});
  function edit(values){try{change(()=>model.edit(values));}catch(e){toast(e.message);inspector();}}
  for(const [id,key] of [['clipIn','in'],['clipOut','out'],['fadeIn','fadeIn'],['fadeOut','fadeOut']])$(id).onchange=()=>edit({[key]:Number($(id).value)});
  $('clipVolume').oninput=()=>{$('volumeText').textContent=$('clipVolume').value+' %';};
  $('clipVolume').onchange=()=>edit({volume:Number($('clipVolume').value)/100});$('clipMute').onchange=()=>edit({muted:$('clipMute').checked});
  bind('fileTool',async()=>{const id=$('toolSource').value;if(!id)throw Error('Importa un archivo primero.');await api('exportar',[id],$('operation').value,Number($('toolIn').value),Number($('toolOut').value));toast('Procesando el archivo por separado.');});
  bind('export',async()=>{if(!model.clips.length)throw Error('Agrega fragmentos a la línea de tiempo.');await api('exportar_proyecto',model.snapshot().clips,$('projectFormat').value);toast('Exportando tu edición con todos los cambios.');});
  function tick(){cursor=Math.min(total(),playingFrom+audio.currentTime);renderCursor();if(!audio.paused)raf=requestAnimationFrame(tick);}
  bind('play',async()=>{
    if(!model.clips.length)throw Error('Agrega una canción a la secuencia.');
    if(!audio.paused){audio.pause();cancelAnimationFrame(raf);$('play').textContent='▶';return;}
    if(blobURL&&!audio.ended){await audio.play();$('play').textContent='Ⅱ';raf=requestAnimationFrame(tick);return;}
    stop();if(cursor>=total()-.01)cursor=0;playingFrom=cursor;const token=generation;
    $('play').textContent='…';$('previewStatus').textContent='Preparando escucha con efectos…';
    try{
      const result=await api('escuchar_proyecto',model.snapshot().clips,cursor);if(token!==generation)return;
      previewLength=result.duration;
      const raw=atob(result.audio),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
      blobURL=URL.createObjectURL(new Blob([bytes],{type:'audio/wav'}));audio.src=blobURL;await audio.play();
      if(token!==generation){audio.pause();return;}
      $('play').textContent='Ⅱ';$('previewStatus').textContent='Escuchando edición · hasta 60 s';raf=requestAnimationFrame(tick);
    }catch(e){if(token===generation){$('play').textContent='▶';$('previewStatus').textContent='No se pudo preparar la escucha';}throw e;}
  });
  audio.onended=()=>{cursor=Math.min(total(),playingFrom+previewLength);$('play').textContent='▶';$('previewStatus').textContent=cursor<total()-.01?'Pulsa ▶ para escuchar el siguiente tramo':'Escucha finalizada';renderCursor();};
  bind('stop',()=>stop(true));
  document.addEventListener('keydown',e=>{if(page!=='editor'||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)||e.target.isContentEditable)return;let id=null;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z')id=e.shiftKey?'redo':'undo';else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y')id='redo';else if(e.code==='Space')id='play';else if(e.key==='Delete')id='deleteClip';else if(e.key.toLowerCase()==='s')id='split';if(id){e.preventDefault();$(id).click();}});
  let resizeFrame=0;new ResizeObserver(()=>{cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(()=>{if(page==='editor')render();});}).observe($('studioScroll'));
  window.Studio={render,model};renderLibrary();render();
})();

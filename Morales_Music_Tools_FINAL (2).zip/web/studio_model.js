(function(root){
  'use strict';
  let counter=0;
  const copy=value=>JSON.parse(JSON.stringify(value));
  class StudioModel{
    constructor(){this.clips=[];this.selected=null;this.undoStack=[];this.redoStack=[];}
    snapshot(){return copy({clips:this.clips,selected:this.selected});}
    remember(before=this.snapshot()){this.undoStack.push(before);if(this.undoStack.length>80)this.undoStack.shift();this.redoStack=[];}
    restore(value){this.clips=copy(value.clips);this.selected=value.selected;}
    undo(){if(!this.undoStack.length)return;this.redoStack.push(this.snapshot());this.restore(this.undoStack.pop());}
    redo(){if(!this.redoStack.length)return;this.undoStack.push(this.snapshot());this.restore(this.redoStack.pop());}
    active(){return this.clips.find(c=>c.id===this.selected);}
    total(){return this.clips.reduce((sum,c)=>sum+c.out-c.in,0);}
    offset(id){let t=0;for(const c of this.clips){if(c.id===id)return t;t+=c.out-c.in;}return 0;}
    add(source,name,duration){if(!Number.isFinite(duration)||duration<.01)throw Error('El archivo no tiene audio utilizable.');if(this.clips.length>=200)throw Error('Máximo 200 fragmentos.');this.remember();const c={id:'clip-'+(++counter),source,name,sourceDuration:duration,in:0,out:duration,volume:1,fadeIn:0,fadeOut:0,muted:false};this.clips.push(c);this.selected=c.id;return c;}
    split(cursor){const c=this.active();if(!c)throw Error('Selecciona un fragmento.');const at=cursor-this.offset(c.id);if(at<.01||at>c.out-c.in-.01)throw Error('Coloca el cursor dentro del fragmento seleccionado.');if(this.clips.length>=200)throw Error('Máximo 200 fragmentos.');this.remember();const right={...c,id:'clip-'+(++counter),in:c.in+at,fadeIn:0};c.out=c.in+at;c.fadeOut=0;c.fadeIn=Math.min(c.fadeIn,at);right.fadeOut=Math.min(right.fadeOut,right.out-right.in);this.clips.splice(this.clips.indexOf(c)+1,0,right);this.selected=right.id;}
    remove(){const i=this.clips.findIndex(c=>c.id===this.selected);if(i<0)return;this.remember();this.clips.splice(i,1);this.selected=this.clips[Math.min(i,this.clips.length-1)]?.id||null;}
    duplicate(){const c=this.active();if(!c)return;if(this.clips.length>=200)throw Error('Máximo 200 fragmentos.');this.remember();const other={...c,id:'clip-'+(++counter)};this.clips.splice(this.clips.indexOf(c)+1,0,other);this.selected=other.id;}
    move(id,target){const i=this.clips.findIndex(c=>c.id===id);if(i<0)return;target=Math.max(0,Math.min(this.clips.length-1,target));if(i===target)return;this.remember();const [clip]=this.clips.splice(i,1);this.clips.splice(target,0,clip);this.selected=id;}
    edit(values,remember=true){const c=this.active();if(!c)return;const n={...c,...values};for(const key of ['in','out','volume','fadeIn','fadeOut'])if(!Number.isFinite(n[key]))throw Error('Escribe valores numéricos válidos.');if(n.in<0||n.out>n.sourceDuration||n.out-n.in<.01)throw Error('El inicio y final deben estar dentro del archivo.');if(n.volume<0||n.volume>2||n.fadeIn<0||n.fadeOut<0)throw Error('Revisa el volumen y los efectos.');n.fadeIn=Math.min(n.fadeIn,n.out-n.in);n.fadeOut=Math.min(n.fadeOut,n.out-n.in);if(remember)this.remember();Object.assign(c,n);}
  }
  root.StudioModel=StudioModel;
  if(typeof module!=='undefined'&&module.exports)module.exports=StudioModel;
})(typeof window!=='undefined'?window:globalThis);

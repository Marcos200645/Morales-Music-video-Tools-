@echo off
setlocal
title Crear EXE - Morales Music Tools
cd /d "%~dp0"
color 0A

echo ==================================================
echo       CREAR MORALES MUSIC TOOLS.EXE
echo ==================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado.
    echo Descarguelo desde https://www.python.org/downloads/
    echo y marque la opcion Add Python to PATH.
    pause
    exit /b 1
)

echo [1/4] Instalando herramientas necesarias...
py -m pip install --upgrade pyinstaller yt-dlp Pillow imageio-ffmpeg
if errorlevel 1 goto :error

echo [2/4] Preparando el motor FFmpeg integrado...
echo [3/4] Construyendo el ejecutable. Esto puede tardar varios minutos...
py -m PyInstaller --noconfirm --clean --onefile --windowed ^
 --name "Morales_Music_Tools" ^
 --icon "Morales_Music_Tools.ico" ^
 --add-data "Morales_Music_Tools_Logo.png;." ^
 --add-data "Morales_Music_Tools.ico;." ^
 --collect-all yt_dlp ^
 --collect-all imageio_ffmpeg ^
 "Morales_Music_Tools.py"
if errorlevel 1 goto :error
echo.
echo [4/4] PROCESO TERMINADO CORRECTAMENTE
echo.
echo El programa se creo en:
echo %CD%\dist\Morales_Music_Tools.exe
echo.
start "" "%CD%\dist"
pause
exit /b 0

:error
echo.
echo ERROR: No se pudo crear el ejecutable.
echo Revise los mensajes mostrados arriba.
pause
exit /b 1

"""Morales Music Tools: descargador y convertidor visual de audio y video.

Requisitos:
    Python 3.9+
    pip install yt-dlp Pillow imageio-ffmpeg

El programa no establece límites artificiales de velocidad. La velocidad real
depende del sitio, la conexión y el equipo. Úselo solo con contenido propio o
con autorización para descargarlo.
"""

from __future__ import annotations

import json
import importlib
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    import yt_dlp
except ImportError:
    yt_dlp = None

try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None

try:
    from PIL import Image, ImageTk
    from io import BytesIO
except ImportError:
    Image = ImageTk = BytesIO = None


APP_NAME = "Morales Music Tools"
VERSION = "2.1"
FORMATOS = ("mp3", "m4a", "flac", "wav", "ogg", "opus", "aac")
FORMATOS_VIDEO = ("mp4", "mkv", "webm")
CALIDADES_VIDEO = ("360p", "480p", "720p", "1080p", "Mejor disponible")
CONFIG_DIR = Path.home() / ".morales_music_tools"
CONFIG_FILE = CONFIG_DIR / "config.json"
LOGO_ARCHIVO = "Morales_Music_Tools_Logo.png"
ICONO_ARCHIVO = "Morales_Music_Tools.ico"


def ruta_recurso(nombre: str) -> Path:
    """Encuentra recursos tanto en Python como dentro del ejecutable."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / nombre


def buscar_binario(nombre: str) -> Optional[str]:
    """Busca FFmpeg incluido en el EXE, junto al programa o en PATH."""
    ejecutable = nombre + ".exe" if sys.platform.startswith("win") else nombre
    candidatos = [ruta_recurso(ejecutable), Path(sys.executable).resolve().parent / ejecutable]
    for candidato in candidatos:
        if candidato.is_file():
            return str(candidato)
    if nombre == "ffmpeg" and imageio_ffmpeg is not None:
        try:
            incluido = Path(imageio_ffmpeg.get_ffmpeg_exe())
            if incluido.is_file():
                return str(incluido)
        except Exception:
            pass
    return shutil.which(nombre)


def instalar_componentes_automaticamente() -> None:
    """Instala los componentes al ejecutar el .py por primera vez."""
    global yt_dlp, imageio_ffmpeg, Image, ImageTk, BytesIO
    if getattr(sys, "frozen", False):
        return
    paquetes = []
    if yt_dlp is None:
        paquetes.append("yt-dlp")
    if imageio_ffmpeg is None:
        paquetes.append("imageio-ffmpeg")
    if Image is None:
        paquetes.append("Pillow")
    if not paquetes:
        return
    print("Instalando automáticamente:", ", ".join(paquetes))
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--disable-pip-version-check", *paquetes],
            check=True,
        )
        importlib.invalidate_caches()
        if yt_dlp is None:
            yt_dlp = importlib.import_module("yt_dlp")
        if imageio_ffmpeg is None:
            imageio_ffmpeg = importlib.import_module("imageio_ffmpeg")
        if Image is None:
            Image = importlib.import_module("PIL.Image")
            ImageTk = importlib.import_module("PIL.ImageTk")
            BytesIO = importlib.import_module("io").BytesIO
    except Exception as error:
        print("No se pudieron instalar todos los componentes:", error)


@dataclass
class Trabajo:
    id: int
    tipo: str
    origen: str
    formato: str
    calidad: str = ""
    titulo: str = "Preparando..."
    estado: str = "Pendiente"
    progreso: float = 0.0
    velocidad: str = ""
    eta: str = ""
    miniatura: str = ""
    salida: str = ""
    creado: float = field(default_factory=time.time)


class Cancelado(Exception):
    pass


def formato_tiempo(segundos: Any) -> str:
    try:
        segundos = max(0, int(segundos))
    except (TypeError, ValueError):
        return ""
    minutos, segundo = divmod(segundos, 60)
    hora, minuto = divmod(minutos, 60)
    return f"{hora:02d}:{minuto:02d}:{segundo:02d}" if hora else f"{minuto:02d}:{segundo:02d}"


def bytes_legibles(valor: Any) -> str:
    try:
        numero = float(valor)
    except (TypeError, ValueError):
        return ""
    for unidad in ("B/s", "KB/s", "MB/s", "GB/s"):
        if numero < 1024:
            return f"{numero:.1f} {unidad}"
        numero /= 1024
    return f"{numero:.1f} TB/s"


def salida_unica(ruta: Path) -> Path:
    if not ruta.exists():
        return ruta
    contador = 2
    while True:
        candidata = ruta.with_name(f"{ruta.stem} ({contador}){ruta.suffix}")
        if not candidata.exists():
            return candidata
        contador += 1


class AudioFacil(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {VERSION}")
        self.geometry("1120x720")
        self.minsize(900, 620)
        self.configure(bg="#0d1117")

        self.trabajos: List[Trabajo] = []
        self.siguiente_id = 1
        self.cola: "queue.Queue[Trabajo]" = queue.Queue()
        self.eventos: "queue.Queue[tuple]" = queue.Queue()
        self.procesando = False
        self.cancelar_actual = threading.Event()
        self.proceso_actual: Optional[subprocess.Popen] = None
        self.trabajo_actual: Optional[Trabajo] = None
        self.imagen_actual = None
        self.imagen_video_actual = None
        self.logo_header = None
        self.logo_icono = None
        self.portada_url_actual = ""
        self.portada_video_url_actual = ""
        self.canciones_cargando = 0
        self.cargando_es_playlist = False
        self.tipo_cargando = "descarga"
        self.errores_cola: List[str] = []
        self.ultima_ruta_error: Optional[Path] = None
        self.configuracion = self.cargar_configuracion()

        carpeta_inicial = self.configuracion.get("carpeta", str(Path.home() / "Downloads"))
        self.carpeta = tk.StringVar(value=carpeta_inicial)
        self.formato_descarga = tk.StringVar(value=self.configuracion.get("formato_descarga", "mp3"))
        self.formato_conversion = tk.StringVar(value=self.configuracion.get("formato_conversion", "mp3"))
        self.formato_video = tk.StringVar(value=self.configuracion.get("formato_video", "mp4"))
        self.calidad_video = tk.StringVar(value=self.configuracion.get("calidad_video", "720p"))
        self.url = tk.StringVar()
        self.url_video = tk.StringVar()
        self.estado_general = tk.StringVar(value="Listo")
        self.actual_texto = tk.StringVar(value="Ninguna canción en proceso")
        self.siguiente_texto = tk.StringVar(value="Siguiente: ninguna")
        self.detalle_texto = tk.StringVar(value="0%")
        self.video_actual_texto = tk.StringVar(value="Ningún video en proceso")
        self.video_siguiente_texto = tk.StringVar(value="Siguiente: ninguno")
        self.video_detalle_texto = tk.StringVar(value="0%")

        self.configurar_estilos()
        self.configurar_icono()
        self.crear_interfaz()
        self.protocol("WM_DELETE_WINDOW", self.cerrar)
        self.after(100, self.procesar_eventos)
        self.after(300, self.verificar_componentes)

    def cargar_configuracion(self) -> Dict[str, str]:
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def guardar_configuracion(self) -> None:
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            CONFIG_FILE.write_text(json.dumps({
                "carpeta": self.carpeta.get(),
                "formato_descarga": self.formato_descarga.get(),
                "formato_conversion": self.formato_conversion.get(),
                "formato_video": self.formato_video.get(),
                "calidad_video": self.calidad_video.get(),
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass

    def configurar_estilos(self) -> None:
        estilo = ttk.Style(self)
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass
        estilo.configure("TFrame", background="#0d1117")
        estilo.configure("Card.TFrame", background="#161b22")
        estilo.configure("TLabel", background="#0d1117", foreground="#e6edf3", font=("Segoe UI", 10))
        estilo.configure("Title.TLabel", font=("Segoe UI Semibold", 22), foreground="#58f08b")
        estilo.configure("Sub.TLabel", foreground="#9da7b3")
        estilo.configure("Card.TLabel", background="#161b22", foreground="#e6edf3")
        estilo.configure("Current.TLabel", background="#161b22", foreground="#58f08b", font=("Segoe UI Semibold", 13))
        estilo.configure("TButton", font=("Segoe UI Semibold", 10), padding=(12, 8))
        estilo.configure("Accent.TButton", background="#238636", foreground="white")
        estilo.map("Accent.TButton", background=[("active", "#2ea043")])
        estilo.configure("Danger.TButton", background="#b62324", foreground="white")
        estilo.map("Danger.TButton", background=[("active", "#da3633")])
        estilo.configure("TNotebook", background="#0d1117", borderwidth=0)
        estilo.configure("TNotebook.Tab", background="#21262d", foreground="#c9d1d9", padding=(18, 10))
        estilo.map("TNotebook.Tab", background=[("selected", "#238636")], foreground=[("selected", "white")])
        estilo.configure("Treeview", background="#161b22", fieldbackground="#161b22", foreground="#e6edf3", rowheight=29)
        estilo.configure("Treeview.Heading", background="#21262d", foreground="#e6edf3", font=("Segoe UI Semibold", 9))
        estilo.map("Treeview", background=[("selected", "#1f6feb")])
        estilo.configure("Green.Horizontal.TProgressbar", troughcolor="#21262d", background="#2ea043")

    def configurar_icono(self) -> None:
        icono = ruta_recurso(ICONO_ARCHIVO)
        if icono.is_file() and sys.platform.startswith("win"):
            try:
                self.iconbitmap(str(icono))
            except tk.TclError:
                pass
        logo = ruta_recurso(LOGO_ARCHIVO)
        if not logo.is_file() or Image is None or ImageTk is None:
            return
        try:
            imagen = Image.open(logo).convert("RGBA")
            imagen.thumbnail((128, 128))
            self.logo_icono = ImageTk.PhotoImage(imagen)
            self.iconphoto(True, self.logo_icono)
        except OSError:
            pass

    def crear_interfaz(self) -> None:
        encabezado = ttk.Frame(self, padding=(22, 16))
        encabezado.pack(fill="x")
        logo = ruta_recurso(LOGO_ARCHIVO)
        if logo.is_file() and Image is not None and ImageTk is not None:
            try:
                imagen = Image.open(logo).convert("RGBA")
                imagen.thumbnail((92, 92))
                self.logo_header = ImageTk.PhotoImage(imagen)
                tk.Label(encabezado, image=self.logo_header, bg="#0d1117", borderwidth=0).pack(side="left", padx=(0, 12))
            except OSError:
                pass
        textos = ttk.Frame(encabezado)
        textos.pack(side="left")
        ttk.Label(textos, text="MORALES MUSIC TOOLS", style="Title.TLabel").pack(anchor="w")
        ttk.Label(textos, text="Descarga audio y video; convierte archivos fácilmente", style="Sub.TLabel").pack(anchor="w")
        ttk.Button(encabezado, text="Abrir carpeta", command=self.abrir_carpeta).pack(side="right")
        ttk.Button(encabezado, text="Acerca del creador", command=self.acerca_de).pack(side="right", padx=8)

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        descarga = ttk.Frame(notebook, padding=16)
        videos = ttk.Frame(notebook, padding=16)
        conversion = ttk.Frame(notebook, padding=16)
        notebook.add(descarga, text="Descargar audio")
        notebook.add(videos, text="Descargar videos")
        notebook.add(conversion, text="Convertir archivos")
        self.crear_descargas(descarga)
        self.crear_videos(videos)
        self.crear_conversion(conversion)

        pie = ttk.Frame(self, padding=(20, 5, 20, 12))
        pie.pack(fill="x")
        ttk.Label(pie, textvariable=self.estado_general, style="Sub.TLabel").pack(side="left")
        ttk.Label(pie, text="Creado por Marcos Morales • Instagram: @mmb_morales", style="Sub.TLabel").pack(side="right")

    def acerca_de(self) -> None:
        messagebox.showinfo(
            "Acerca de Morales Music Tools",
            f"{APP_NAME} {VERSION}\n\n"
            "Descargador y convertidor visual de audio y video.\n\n"
            "Creado y desarrollado por:\n"
            "Marcos Morales\n"
            "Instagram: @mmb_morales\n\n"
            "Sin límite artificial de velocidad.\n"
            "Use únicamente contenido propio o autorizado.",
        )

    def crear_selector_carpeta(self, padre: ttk.Frame, fila: int) -> None:
        ttk.Label(padre, text="Guardar en:").grid(row=fila, column=0, sticky="w", pady=7)
        ttk.Entry(padre, textvariable=self.carpeta).grid(row=fila, column=1, sticky="ew", padx=8, pady=7)
        ttk.Button(padre, text="Elegir carpeta", command=self.elegir_carpeta).grid(row=fila, column=2, pady=7)

    def crear_descargas(self, padre: ttk.Frame) -> None:
        superior = ttk.Frame(padre, style="Card.TFrame", padding=16)
        superior.pack(fill="x")
        superior.columnconfigure(1, weight=1)
        ttk.Label(superior, text="Enlace de canción o playlist:", style="Card.TLabel").grid(row=0, column=0, sticky="w", pady=7)
        entrada = ttk.Entry(superior, textvariable=self.url)
        entrada.grid(row=0, column=1, sticky="ew", padx=8, pady=7)
        entrada.bind("<Return>", lambda _e: self.agregar_descarga())
        self.boton_agregar = ttk.Button(superior, text="Agregar enlace o playlist", style="Accent.TButton", command=self.agregar_descarga)
        self.boton_agregar.grid(row=0, column=2, pady=7)
        ttk.Label(superior, text="Formato:", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=7)
        ttk.Combobox(superior, textvariable=self.formato_descarga, values=FORMATOS, state="readonly", width=12).grid(row=1, column=1, sticky="w", padx=8)
        self.crear_selector_carpeta(superior, 2)

        cuerpo = ttk.Frame(padre)
        cuerpo.pack(fill="both", expand=True, pady=(14, 0))
        cuerpo.columnconfigure(0, weight=3)
        cuerpo.columnconfigure(1, weight=2)
        cuerpo.rowconfigure(0, weight=1)

        cola_frame = ttk.Frame(cuerpo, style="Card.TFrame", padding=12)
        cola_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        ttk.Label(cola_frame, text="Canciones disponibles y cola", style="Current.TLabel").pack(anchor="w")
        ttk.Label(cola_frame, text="Selecciona una canción; usa Ctrl para escoger varias.", style="Card.TLabel").pack(anchor="w", pady=(2, 8))
        columnas = ("titulo", "formato", "estado", "progreso")
        self.tabla = ttk.Treeview(cola_frame, columns=columnas, show="headings", selectmode="extended")
        self.tabla.heading("titulo", text="Canción / archivo")
        self.tabla.heading("formato", text="Formato")
        self.tabla.heading("estado", text="Estado")
        self.tabla.heading("progreso", text="Avance")
        self.tabla.column("titulo", width=320, anchor="w")
        self.tabla.column("formato", width=75, anchor="center")
        self.tabla.column("estado", width=105, anchor="center")
        self.tabla.column("progreso", width=80, anchor="center")
        barra = ttk.Scrollbar(cola_frame, orient="vertical", command=self.tabla.yview)
        self.tabla.configure(yscrollcommand=barra.set)
        self.tabla.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")

        actual = ttk.Frame(cuerpo, style="Card.TFrame", padding=16)
        actual.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        actual.columnconfigure(0, weight=1)
        self.portada = tk.Label(actual, text="♪", font=("Segoe UI", 72), bg="#0b0f14", fg="#58f08b", width=6, height=3)
        self.portada.grid(row=0, column=0, sticky="n", pady=(0, 12))
        ttk.Label(actual, textvariable=self.actual_texto, style="Current.TLabel", wraplength=360, justify="center").grid(row=1, column=0, sticky="ew")
        ttk.Label(actual, textvariable=self.siguiente_texto, style="Card.TLabel", wraplength=360, justify="center").grid(row=2, column=0, sticky="ew", pady=(8, 14))
        self.progreso = ttk.Progressbar(actual, maximum=100, style="Green.Horizontal.TProgressbar")
        self.progreso.grid(row=3, column=0, sticky="ew")
        ttk.Label(actual, textvariable=self.detalle_texto, style="Card.TLabel").grid(row=4, column=0, pady=8)
        botones = ttk.Frame(actual, style="Card.TFrame")
        botones.grid(row=5, column=0, pady=8)
        ttk.Button(botones, text="Descargar selección", style="Accent.TButton", command=self.descargar_seleccionadas).grid(row=0, column=0, padx=4, pady=4)
        ttk.Button(botones, text="Descargar todas", command=lambda: self.descargar_todas("descarga")).grid(row=0, column=1, padx=4, pady=4)
        ttk.Button(botones, text="Cancelar actual", style="Danger.TButton", command=self.cancelar).grid(row=1, column=0, padx=4, pady=4)
        ttk.Button(botones, text="Quitar seleccionadas", command=self.quitar_seleccionado).grid(row=1, column=1, padx=4, pady=4)

    def crear_videos(self, padre: ttk.Frame) -> None:
        superior = ttk.Frame(padre, style="Card.TFrame", padding=16)
        superior.pack(fill="x")
        superior.columnconfigure(1, weight=1)
        ttk.Label(superior, text="Enlace de video o playlist:", style="Card.TLabel").grid(row=0, column=0, sticky="w", pady=7)
        entrada = ttk.Entry(superior, textvariable=self.url_video)
        entrada.grid(row=0, column=1, sticky="ew", padx=8, pady=7)
        entrada.bind("<Return>", lambda _e: self.agregar_video())
        self.boton_agregar_video = ttk.Button(superior, text="Mostrar videos", style="Accent.TButton", command=self.agregar_video)
        self.boton_agregar_video.grid(row=0, column=2, pady=7)
        ttk.Label(superior, text="Formato:", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=7)
        opciones = ttk.Frame(superior, style="Card.TFrame")
        opciones.grid(row=1, column=1, sticky="w", padx=8)
        ttk.Combobox(opciones, textvariable=self.formato_video, values=FORMATOS_VIDEO, state="readonly", width=10).pack(side="left")
        ttk.Label(opciones, text="Calidad:", style="Card.TLabel").pack(side="left", padx=(20, 8))
        ttk.Combobox(opciones, textvariable=self.calidad_video, values=CALIDADES_VIDEO, state="readonly", width=18).pack(side="left")
        self.crear_selector_carpeta(superior, 2)

        cuerpo = ttk.Frame(padre)
        cuerpo.pack(fill="both", expand=True, pady=(14, 0))
        cuerpo.columnconfigure(0, weight=3)
        cuerpo.columnconfigure(1, weight=2)
        cuerpo.rowconfigure(0, weight=1)

        lista = ttk.Frame(cuerpo, style="Card.TFrame", padding=12)
        lista.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        ttk.Label(lista, text="Videos disponibles", style="Current.TLabel").pack(anchor="w")
        ttk.Label(lista, text="Selecciona uno; usa Ctrl para escoger varios.", style="Card.TLabel").pack(anchor="w", pady=(2, 8))
        columnas = ("titulo", "formato", "estado", "progreso")
        self.tabla_video = ttk.Treeview(lista, columns=columnas, show="headings", selectmode="extended")
        for columna, texto in (("titulo", "Video"), ("formato", "Formato/calidad"), ("estado", "Estado"), ("progreso", "Avance")):
            self.tabla_video.heading(columna, text=texto)
        self.tabla_video.column("titulo", width=560, anchor="w")
        self.tabla_video.column("formato", width=150, anchor="center")
        self.tabla_video.column("estado", width=115, anchor="center")
        self.tabla_video.column("progreso", width=85, anchor="center")
        barra = ttk.Scrollbar(lista, orient="vertical", command=self.tabla_video.yview)
        self.tabla_video.configure(yscrollcommand=barra.set)
        self.tabla_video.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")

        vista = ttk.Frame(cuerpo, style="Card.TFrame", padding=16)
        vista.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        vista.columnconfigure(0, weight=1)
        self.portada_video = tk.Label(
            vista, text="▶", font=("Segoe UI", 64), bg="#0b0f14", fg="#58f08b",
            width=6, height=3,
        )
        self.portada_video.grid(row=0, column=0, sticky="n", pady=(0, 12))
        ttk.Label(
            vista, textvariable=self.video_actual_texto, style="Current.TLabel",
            wraplength=360, justify="center",
        ).grid(row=1, column=0, sticky="ew")
        ttk.Label(
            vista, textvariable=self.video_siguiente_texto, style="Card.TLabel",
            wraplength=360, justify="center",
        ).grid(row=2, column=0, sticky="ew", pady=(8, 14))
        self.progreso_video = ttk.Progressbar(vista, maximum=100, style="Green.Horizontal.TProgressbar")
        self.progreso_video.grid(row=3, column=0, sticky="ew")
        ttk.Label(vista, textvariable=self.video_detalle_texto, style="Card.TLabel").grid(row=4, column=0, pady=8)
        botones = ttk.Frame(vista, style="Card.TFrame")
        botones.grid(row=5, column=0, pady=8)
        ttk.Button(botones, text="Descargar selección", style="Accent.TButton", command=lambda: self.descargar_seleccionadas(self.tabla_video)).pack(fill="x", pady=4)
        ttk.Button(botones, text="Descargar todos", command=lambda: self.descargar_todas("video")).pack(fill="x", pady=4)
        ttk.Button(botones, text="Cancelar actual", style="Danger.TButton", command=self.cancelar).pack(fill="x", pady=4)
        ttk.Button(botones, text="Quitar seleccionados", command=lambda: self.quitar_seleccionado(self.tabla_video)).pack(fill="x", pady=4)

    def crear_conversion(self, padre: ttk.Frame) -> None:
        tarjeta = ttk.Frame(padre, style="Card.TFrame", padding=24)
        tarjeta.pack(fill="x")
        tarjeta.columnconfigure(1, weight=1)
        ttk.Label(tarjeta, text="CONVERTIR ARCHIVOS LOCALES", style="Current.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 12))
        ttk.Label(tarjeta, text="Seleccione uno o varios audios. FFmpeg reconoce la mayoría de formatos.", style="Card.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 16))
        ttk.Label(tarjeta, text="Convertir a:", style="Card.TLabel").grid(row=2, column=0, sticky="w", pady=7)
        ttk.Combobox(tarjeta, textvariable=self.formato_conversion, values=FORMATOS, state="readonly", width=12).grid(row=2, column=1, sticky="w", padx=8)
        self.crear_selector_carpeta(tarjeta, 3)
        ttk.Button(tarjeta, text="Seleccionar audios y agregar", style="Accent.TButton", command=self.agregar_conversiones).grid(row=4, column=0, columnspan=3, sticky="ew", pady=(16, 7))
        ttk.Button(tarjeta, text="Iniciar toda la cola", command=self.iniciar_cola).grid(row=5, column=0, columnspan=3, sticky="ew", pady=7)

        ayuda = ttk.Frame(padre, padding=24)
        ayuda.pack(fill="both", expand=True)
        ttk.Label(ayuda, text="Formatos disponibles", style="Title.TLabel").pack(anchor="w")
        ttk.Label(ayuda, text="MP3 para máxima compatibilidad • M4A/AAC para buen tamaño • FLAC/WAV para mayor fidelidad • OGG/OPUS para archivos eficientes", style="Sub.TLabel", wraplength=850).pack(anchor="w", pady=10)
        ttk.Label(ayuda, text="Las conversiones también aparecen en la cola de la pestaña Descargar audio.", style="Sub.TLabel").pack(anchor="w")

    def verificar_componentes(self) -> None:
        faltan = []
        if yt_dlp is None:
            faltan.append("yt-dlp (solo para descargas)")
        if not buscar_binario("ffmpeg"):
            faltan.append("FFmpeg")
        if faltan:
            self.estado_general.set("Falta instalar: " + ", ".join(faltan))
        else:
            self.estado_general.set("Todos los componentes están listos")

    def elegir_carpeta(self) -> None:
        carpeta = filedialog.askdirectory(initialdir=self.carpeta.get() or str(Path.home()))
        if carpeta:
            self.carpeta.set(carpeta)
            self.guardar_configuracion()

    def abrir_carpeta(self) -> None:
        carpeta = Path(self.carpeta.get()).expanduser()
        carpeta.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(carpeta))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(carpeta)])
            else:
                subprocess.Popen(["xdg-open", str(carpeta)])
        except OSError as error:
            messagebox.showerror("No se pudo abrir", str(error))

    def agregar_descarga(self) -> None:
        enlace = self.url.get().strip()
        if not enlace.startswith(("http://", "https://")):
            messagebox.showwarning("Enlace inválido", "Pegue un enlace que comience con http:// o https://")
            return
        if yt_dlp is None:
            messagebox.showerror("Falta un componente", "No se encontró yt-dlp. Ejecute el instalador del programa.")
            return
        formato = self.formato_descarga.get()
        self.url.set("")
        self.boton_agregar.configure(state="disabled", text="Leyendo enlace...")
        self.estado_general.set("Leyendo la información del enlace o playlist...")
        if hasattr(self, "boton_agregar_video"):
            self.boton_agregar_video.configure(state="disabled")
        threading.Thread(target=self.expandir_enlace, args=(enlace, formato, "descarga", ""), daemon=True).start()

    def agregar_video(self) -> None:
        enlace = self.url_video.get().strip()
        if not enlace.startswith(("http://", "https://")):
            messagebox.showwarning("Enlace inválido", "Pegue un enlace que comience con http:// o https://")
            return
        if yt_dlp is None:
            messagebox.showerror("Falta un componente", "No se encontró yt-dlp. Ejecute el instalador del programa.")
            return
        self.url_video.set("")
        self.boton_agregar.configure(state="disabled")
        self.boton_agregar_video.configure(state="disabled", text="Leyendo enlace...")
        self.estado_general.set("Leyendo información de video o playlist...")
        threading.Thread(
            target=self.expandir_enlace,
            args=(enlace, self.formato_video.get(), "video", self.calidad_video.get()),
            daemon=True,
        ).start()

    def expandir_enlace(self, enlace: str, formato: str, tipo_trabajo: str,
                        calidad: str) -> None:
        """Convierte un enlace individual o playlist en trabajos separados."""
        try:
            opciones = {
                "quiet": True,
                "no_warnings": True,
                "skip_download": True,
                "extract_flat": True,
                "lazy_playlist": True,
                "noplaylist": False,
                "ignoreerrors": True,
                "socket_timeout": 12,
                "retries": 3,
            }
            with yt_dlp.YoutubeDL(opciones) as ydl:
                info = ydl.extract_info(enlace, download=False)
            if not info:
                raise RuntimeError("No se pudo leer el enlace. Puede ser privado, estar bloqueado o no existir.")
            entradas = info.get("entries")
            es_individual = entradas is None
            if entradas is None:
                entradas = [info]
            nombre_lista = info.get("title") or ""
            self.eventos.put(("playlist_inicio", nombre_lista, not es_individual, tipo_trabajo))
            lote = []
            cantidad = 0
            for entrada in entradas:
                if not entrada:
                    continue
                url = entrada.get("webpage_url") or entrada.get("original_url") or entrada.get("url") or ""
                identificador = entrada.get("id") or ""
                extractor = str(entrada.get("extractor_key") or info.get("extractor_key") or "").lower()
                if not str(url).startswith(("http://", "https://")) and "youtube" in extractor and identificador:
                    url = f"https://www.youtube.com/watch?v={identificador}"
                if not str(url).startswith(("http://", "https://")):
                    if es_individual:
                        url = enlace
                    else:
                        continue
                miniatura = entrada.get("thumbnail") or ""
                if not miniatura and entrada.get("thumbnails"):
                    miniatura = entrada["thumbnails"][-1].get("url") or ""
                lote.append({
                    "url": str(url),
                    "titulo": entrada.get("title") or "Audio sin título",
                    "miniatura": miniatura,
                    "formato": formato,
                    "tipo": tipo_trabajo,
                    "calidad": calidad,
                })
                cantidad += 1
                if len(lote) >= 10:
                    self.eventos.put(("canciones_parciales", lote, nombre_lista, False))
                    lote = []
            if cantidad == 0:
                raise RuntimeError("No se encontraron canciones disponibles dentro del enlace.")
            if lote:
                self.eventos.put(("canciones_parciales", lote, nombre_lista, True))
            else:
                self.eventos.put(("canciones_parciales", [], nombre_lista, True))
        except Exception as error:
            self.eventos.put(("enlace_error", str(error), traceback.format_exc()))

    def agregar_conversiones(self) -> None:
        archivos = filedialog.askopenfilenames(title="Seleccione archivos de audio", filetypes=[
            ("Archivos de audio", "*.mp3 *.m4a *.aac *.wav *.flac *.ogg *.opus *.wma *.aiff *.amr *.ac3 *.webm *.mp4 *.mkv"),
            ("Todos los archivos", "*.*"),
        ])
        for archivo in archivos:
            trabajo = Trabajo(self.siguiente_id, "conversion", archivo, self.formato_conversion.get(), titulo=Path(archivo).name)
            self.siguiente_id += 1
            self.agregar_trabajo(trabajo)
        if archivos:
            self.iniciar_cola()

    def agregar_trabajo(self, trabajo: Trabajo) -> None:
        self.trabajos.append(trabajo)
        if trabajo.tipo == "video" and hasattr(self, "tabla_video"):
            self.tabla_video.insert("", "end", iid=str(trabajo.id), values=self.valores_trabajo(trabajo))
        else:
            self.tabla.insert("", "end", iid=str(trabajo.id), values=self.valores_trabajo(trabajo))
        if self.procesando:
            self.cola.put(trabajo)
        self.actualizar_siguiente()
        self.guardar_configuracion()

    def descargar_seleccionadas(self, tabla: Optional[ttk.Treeview] = None) -> None:
        tabla = tabla or self.tabla
        seleccion = tabla.selection()
        if not seleccion:
            messagebox.showinfo("Seleccione canciones", "Haz clic en una canción. Para varias, mantén presionada la tecla Ctrl.")
            return
        elegidos = []
        for identificador in seleccion:
            trabajo = next((x for x in self.trabajos if x.id == int(identificador)), None)
            if trabajo and trabajo.estado == "Disponible":
                trabajo.estado = "Pendiente"
                elegidos.append(trabajo)
                self.actualizar_fila(trabajo)
        if not elegidos:
            messagebox.showinfo("Sin canciones disponibles", "La selección ya fue descargada, quitada o está en proceso.")
            return
        self.activar_trabajos(elegidos)

    def descargar_todas(self, tipo: Optional[str] = None) -> None:
        elegidos = [x for x in self.trabajos if x.estado == "Disponible" and (tipo is None or x.tipo == tipo)]
        for trabajo in elegidos:
            trabajo.estado = "Pendiente"
            self.actualizar_fila(trabajo)
        if not elegidos:
            messagebox.showinfo("Sin canciones", "No hay canciones disponibles para descargar.")
            return
        self.activar_trabajos(elegidos)

    def activar_trabajos(self, trabajos: List[Trabajo]) -> None:
        if self.procesando:
            for trabajo in trabajos:
                self.cola.put(trabajo)
            self.actualizar_siguiente()
        else:
            self.iniciar_cola()

    def quitar_seleccionado(self, tabla: Optional[ttk.Treeview] = None) -> None:
        tabla = tabla or self.tabla
        seleccion = tabla.selection()
        if not seleccion:
            return
        quitados = 0
        for identificador in seleccion:
            trabajo = next((x for x in self.trabajos if x.id == int(identificador)), None)
            if trabajo and trabajo.estado in ("Disponible", "Pendiente"):
                trabajo.estado = "Quitado"
                self.actualizar_fila(trabajo)
                quitados += 1
        self.actualizar_siguiente()
        if not quitados:
            messagebox.showinfo("No disponible", "Solo se pueden quitar canciones disponibles o pendientes.")

    def iniciar_cola(self) -> None:
        if self.procesando:
            return
        pendientes = [x for x in self.trabajos if x.estado == "Pendiente"]
        if not pendientes:
            messagebox.showinfo("Cola vacía", "Agregue al menos una descarga o conversión.")
            return
        if not buscar_binario("ffmpeg"):
            messagebox.showerror(
                "Falta el motor de audio",
                "FFmpeg no está disponible. Ejecute INSTALAR_Morales_Music_Tools.bat "
                "y después vuelva a abrir el programa.",
            )
            return
        carpeta = Path(self.carpeta.get()).expanduser()
        try:
            carpeta.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            messagebox.showerror("Carpeta inválida", str(error))
            return
        for trabajo in pendientes:
            self.cola.put(trabajo)
        self.errores_cola = []
        self.ultima_ruta_error = None
        self.procesando = True
        self.cancelar_actual.clear()
        threading.Thread(target=self.trabajador, daemon=True).start()

    def trabajador(self) -> None:
        while True:
            try:
                trabajo = self.cola.get(timeout=0.4)
            except queue.Empty:
                break
            if trabajo.estado != "Pendiente":
                self.cola.task_done()
                continue
            self.trabajo_actual = trabajo
            self.cancelar_actual.clear()
            trabajo.estado = "Procesando"
            self.eventos.put(("inicio", trabajo))
            try:
                if trabajo.tipo == "descarga":
                    self.descargar(trabajo)
                elif trabajo.tipo == "video":
                    self.descargar_video(trabajo)
                else:
                    self.convertir(trabajo)
                if self.cancelar_actual.is_set():
                    raise Cancelado()
                trabajo.estado = "Completado"
                trabajo.progreso = 100
                self.eventos.put(("terminado", trabajo))
            except Cancelado:
                trabajo.estado = "Cancelado"
                self.eventos.put(("actualizar", trabajo))
            except Exception as error:
                trabajo.estado = "Error"
                self.eventos.put(("error", trabajo, str(error), traceback.format_exc()))
            finally:
                self.proceso_actual = None
                self.cola.task_done()
        self.procesando = False
        self.trabajo_actual = None
        self.eventos.put(("cola_finalizada",))

    def descargar(self, trabajo: Trabajo) -> None:
        if yt_dlp is None:
            raise RuntimeError("Falta yt-dlp. Instálelo con: pip install yt-dlp")
        ffmpeg = buscar_binario("ffmpeg")
        if not ffmpeg:
            raise RuntimeError("Falta FFmpeg. Es necesario para convertir el audio.")
        carpeta = Path(self.carpeta.get()).expanduser()
        ultimo_aviso = [0.0]

        def progreso(datos: Dict[str, Any]) -> None:
            if self.cancelar_actual.is_set():
                raise Cancelado()
            info = datos.get("info_dict") or {}
            if info.get("title"):
                trabajo.titulo = info["title"]
            if info.get("thumbnail"):
                trabajo.miniatura = info["thumbnail"]
            if datos.get("status") == "downloading":
                total = datos.get("total_bytes") or datos.get("total_bytes_estimate") or 0
                descargado = datos.get("downloaded_bytes") or 0
                trabajo.progreso = (descargado * 100 / total) if total else trabajo.progreso
                trabajo.velocidad = bytes_legibles(datos.get("speed"))
                trabajo.eta = formato_tiempo(datos.get("eta"))
            elif datos.get("status") == "finished":
                trabajo.progreso = 99
                trabajo.velocidad = "Convirtiendo"
                trabajo.salida = datos.get("filename") or ""
            ahora = time.monotonic()
            if datos.get("status") == "finished" or ahora - ultimo_aviso[0] >= 0.12:
                ultimo_aviso[0] = ahora
                self.eventos.put(("progreso", trabajo))

        with tempfile.TemporaryDirectory(prefix="morales_music_tools_") as temporal:
            opciones = {
                "format": "bestaudio[ext=m4a]/bestaudio/best",
                "outtmpl": str(Path(temporal) / "%(title).180B [%(id)s].%(ext)s"),
                "noplaylist": True,
                "progress_hooks": [progreso],
                "quiet": True,
                "no_warnings": True,
                "overwrites": True,
                "continuedl": True,
                "retries": 10,
                "fragment_retries": 10,
                "concurrent_fragment_downloads": 8,
                "buffersize": 1024 * 1024,
                "http_chunk_size": 10 * 1024 * 1024,
                "windowsfilenames": sys.platform.startswith("win"),
            }
            with yt_dlp.YoutubeDL(opciones) as ydl:
                info = ydl.extract_info(trabajo.origen, download=True)
                trabajo.titulo = info.get("title") or trabajo.titulo
                trabajo.miniatura = info.get("thumbnail") or trabajo.miniatura
                candidatos = []
                for descarga in info.get("requested_downloads") or []:
                    if descarga.get("filepath"):
                        candidatos.append(Path(descarga["filepath"]))
                if info.get("filepath"):
                    candidatos.append(Path(info["filepath"]))
                candidatos.append(Path(ydl.prepare_filename(info)))
                archivo_descargado = next((ruta for ruta in candidatos if ruta.is_file()), None)
                if archivo_descargado is None:
                    raise RuntimeError("La descarga terminó, pero no se encontró el archivo de audio generado.")

            if archivo_descargado.suffix.lower() == "." + trabajo.formato.lower():
                destino = salida_unica(carpeta / archivo_descargado.name)
                shutil.move(str(archivo_descargado), str(destino))
                trabajo.salida = str(destino)
            else:
                trabajo.velocidad = "Convirtiendo a " + trabajo.formato.upper()
                trabajo.progreso = 99
                self.eventos.put(("progreso", trabajo))
                self.convertir(trabajo, origen_forzado=archivo_descargado, mantener_progreso=True)

        salida_final = Path(trabajo.salida)
        if salida_final.suffix.lower() != "." + trabajo.formato.lower():
            raise RuntimeError(f"El archivo final no quedó en formato {trabajo.formato.upper()}.")

    def descargar_video(self, trabajo: Trabajo) -> None:
        if yt_dlp is None:
            raise RuntimeError("Falta yt-dlp. Ejecute el instalador del programa.")
        ffmpeg = buscar_binario("ffmpeg")
        if not ffmpeg:
            raise RuntimeError("Falta el motor FFmpeg integrado.")
        carpeta = Path(self.carpeta.get()).expanduser()
        trabajo.velocidad = "Analizando calidades"
        self.eventos.put(("progreso", trabajo))
        opciones_info = {
            "quiet": True, "no_warnings": True, "skip_download": True,
            "noplaylist": True, "socket_timeout": 15, "retries": 5,
        }
        with yt_dlp.YoutubeDL(opciones_info) as ydl:
            info = ydl.extract_info(trabajo.origen, download=False)
        if not info:
            raise RuntimeError("No se pudo obtener la información del video.")
        trabajo.titulo = info.get("title") or trabajo.titulo
        trabajo.miniatura = info.get("thumbnail") or trabajo.miniatura
        video, audio = self.elegir_formatos_video(info, trabajo.calidad, trabajo.formato)
        if video is None:
            raise RuntimeError("No se encontró una calidad de video compatible.")

        identificador = str(info.get("id") or trabajo.id)
        try:
            nombre_limpio = yt_dlp.utils.sanitize_filename(trabajo.titulo, restricted=False)
        except Exception:
            nombre_limpio = re.sub(r'[<>:"/\\|?*]+', "_", trabajo.titulo)
        nombre_limpio = nombre_limpio[:170].rstrip(" .") or "video"

        with tempfile.TemporaryDirectory(prefix="morales_video_") as temporal:
            temporal_path = Path(temporal)
            archivo_video = self.descargar_formato_video(
                trabajo, str(video["format_id"]), temporal_path / "video.%(ext)s", 0, 78
            )
            archivo_audio = None
            if audio is not None:
                archivo_audio = self.descargar_formato_video(
                    trabajo, str(audio["format_id"]), temporal_path / "audio.%(ext)s", 78, 90
                )
            destino = salida_unica(carpeta / f"{nombre_limpio} [{identificador}].{trabajo.formato}")
            trabajo.velocidad = "Uniendo video y audio"
            trabajo.progreso = 91
            self.eventos.put(("progreso", trabajo))
            self.unir_video_audio(ffmpeg, archivo_video, archivo_audio, destino, trabajo)
            trabajo.salida = str(destino)
            self.verificar_archivo_video(destino, ffmpeg)

    @staticmethod
    def elegir_formatos_video(info: Dict[str, Any], calidad: str,
                              contenedor: str) -> tuple:
        formatos = [f for f in (info.get("formats") or []) if f and f.get("format_id")]
        limite = None if calidad == "Mejor disponible" else int(calidad.rstrip("p"))
        videos = [f for f in formatos if f.get("vcodec") not in (None, "none") and f.get("height")]
        if limite is not None:
            dentro = [f for f in videos if int(f.get("height") or 0) <= limite]
            if dentro:
                videos = dentro
            else:
                superiores = [f for f in videos if int(f.get("height") or 0) > limite]
                if superiores:
                    altura_minima = min(int(f.get("height") or 0) for f in superiores)
                    videos = [f for f in superiores if int(f.get("height") or 0) == altura_minima]
        extension_preferida = "mp4" if contenedor == "mp4" else "webm" if contenedor == "webm" else ""

        def puntuacion_video(formato: Dict[str, Any]) -> tuple:
            return (
                int(formato.get("height") or 0),
                1 if formato.get("acodec") in (None, "none") else 0,
                1 if extension_preferida and formato.get("ext") == extension_preferida else 0,
                float(formato.get("tbr") or 0),
            )

        if not videos:
            return None, None
        elegido = max(videos, key=puntuacion_video)
        if elegido.get("acodec") not in (None, "none"):
            return elegido, None
        audios = [f for f in formatos if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none")]
        audio_ext = "m4a" if contenedor == "mp4" else "webm" if contenedor == "webm" else ""
        if not audios:
            return elegido, None
        audio = max(audios, key=lambda f: (
            1 if audio_ext and f.get("ext") == audio_ext else 0,
            float(f.get("abr") or f.get("tbr") or 0),
        ))
        return elegido, audio

    def descargar_formato_video(self, trabajo: Trabajo, formato_id: str,
                                plantilla: Path, inicio: float, fin: float) -> Path:
        ultimo = [0.0]

        def progreso(datos: Dict[str, Any]) -> None:
            if self.cancelar_actual.is_set():
                raise Cancelado()
            if datos.get("status") == "downloading":
                total = datos.get("total_bytes") or datos.get("total_bytes_estimate") or 0
                descargado = datos.get("downloaded_bytes") or 0
                proporcion = descargado / total if total else 0
                trabajo.progreso = inicio + (fin - inicio) * proporcion
                trabajo.velocidad = bytes_legibles(datos.get("speed"))
                trabajo.eta = formato_tiempo(datos.get("eta"))
            elif datos.get("status") == "finished":
                trabajo.progreso = fin
            ahora = time.monotonic()
            if datos.get("status") == "finished" or ahora - ultimo[0] >= 0.12:
                ultimo[0] = ahora
                self.eventos.put(("progreso", trabajo))

        opciones = {
            "format": formato_id,
            "outtmpl": str(plantilla),
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "overwrites": True,
            "continuedl": True,
            "retries": 10,
            "fragment_retries": 10,
            "concurrent_fragment_downloads": 8,
            "progress_hooks": [progreso],
        }
        with yt_dlp.YoutubeDL(opciones) as ydl:
            resultado = ydl.extract_info(trabajo.origen, download=True)
            candidatos = []
            for descarga in resultado.get("requested_downloads") or []:
                if descarga.get("filepath"):
                    candidatos.append(Path(descarga["filepath"]))
            candidatos.append(Path(ydl.prepare_filename(resultado)))
        archivo = next((ruta for ruta in candidatos if ruta.is_file()), None)
        if archivo is None:
            raise RuntimeError("No se encontró uno de los archivos descargados del video.")
        return archivo

    def unir_video_audio(self, ffmpeg: str, video: Path, audio: Optional[Path],
                         destino: Path, trabajo: Trabajo) -> None:
        comando = [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(video)]
        if audio is not None:
            comando += ["-i", str(audio), "-map", "0:v:0", "-map", "1:a:0"]
        else:
            comando += ["-map", "0:v:0", "-map", "0:a:0?"]
        if trabajo.formato == "mp4":
            codec_video = "copy" if video.suffix.lower() in (".mp4", ".m4v") else "libx264"
            comando += ["-c:v", codec_video]
            if codec_video != "copy":
                comando += ["-preset", "veryfast", "-crf", "20"]
            comando += ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart"]
        elif trabajo.formato == "webm":
            codec_video = "copy" if video.suffix.lower() == ".webm" else "libvpx-vp9"
            comando += ["-c:v", codec_video]
            if codec_video != "copy":
                comando += ["-deadline", "good", "-cpu-used", "4", "-crf", "30", "-b:v", "0"]
            comando += ["-c:a", "libopus", "-b:a", "160k"]
        else:
            comando += ["-c", "copy"]
        comando += ["-progress", "pipe:1", "-nostats", "-y", str(destino)]
        self.proceso_actual = subprocess.Popen(
            comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
        )
        assert self.proceso_actual.stdout is not None
        for linea in self.proceso_actual.stdout:
            if self.cancelar_actual.is_set():
                self.proceso_actual.terminate()
                raise Cancelado()
            if linea.startswith("progress="):
                trabajo.progreso = 99 if "end" in linea else 95
                self.eventos.put(("progreso", trabajo))
        codigo = self.proceso_actual.wait()
        if codigo != 0:
            error = self.proceso_actual.stderr.read().strip() if self.proceso_actual.stderr else ""
            try:
                destino.unlink()
            except OSError:
                pass
            raise RuntimeError(error[-800:] or "No se pudo unir el video y el audio.")

    @staticmethod
    def verificar_archivo_video(archivo: Path, ffmpeg: str) -> None:
        resultado = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(archivo)],
            capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace",
        )
        descripcion = resultado.stderr.casefold()
        if "video:" not in descripcion:
            raise RuntimeError("El archivo final no contiene una pista de video válida.")
        if "audio:" not in descripcion:
            raise RuntimeError("El archivo final no contiene una pista de audio válida.")

    def convertir(self, trabajo: Trabajo, origen_forzado: Optional[Path] = None,
                  mantener_progreso: bool = False) -> None:
        ffmpeg = buscar_binario("ffmpeg")
        if not ffmpeg:
            raise RuntimeError("Falta FFmpeg. Ejecute el instalador antes de convertir.")
        origen = Path(origen_forzado or trabajo.origen)
        if not origen.is_file():
            raise RuntimeError("El archivo de origen ya no existe.")
        carpeta = Path(self.carpeta.get()).expanduser()
        destino = salida_unica(carpeta / f"{origen.stem}.{trabajo.formato}")
        duracion = self.obtener_duracion(ffmpeg, origen)
        codecs = {
            "mp3": ["-codec:a", "libmp3lame", "-q:a", "0"],
            "m4a": ["-codec:a", "aac", "-b:a", "256k"],
            "aac": ["-codec:a", "aac", "-b:a", "256k"],
            "flac": ["-codec:a", "flac"],
            "wav": ["-codec:a", "pcm_s16le"],
            "ogg": ["-codec:a", "libvorbis", "-q:a", "7"],
            "opus": ["-codec:a", "libopus", "-b:a", "192k"],
        }
        comando = [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(origen), "-vn"]
        comando += codecs[trabajo.formato]
        comando += ["-progress", "pipe:1", "-nostats", "-y", str(destino)]
        self.proceso_actual = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        assert self.proceso_actual.stdout is not None
        for linea in self.proceso_actual.stdout:
            if self.cancelar_actual.is_set():
                self.proceso_actual.terminate()
                try:
                    self.proceso_actual.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.proceso_actual.kill()
                try:
                    destino.unlink()
                except OSError:
                    pass
                raise Cancelado()
            clave, _, valor = linea.strip().partition("=")
            if clave in ("out_time_us", "out_time_ms") and duracion > 0:
                # FFmpeg suele expresar ambos campos en microsegundos.
                try:
                    actual = float(valor) / 1_000_000
                except ValueError:
                    continue
                if not mantener_progreso:
                    trabajo.progreso = min(99, actual * 100 / duracion)
                    self.eventos.put(("progreso", trabajo))
        codigo = self.proceso_actual.wait()
        if codigo != 0:
            error = self.proceso_actual.stderr.read().strip() if self.proceso_actual.stderr else ""
            raise RuntimeError(error[-500:] or "FFmpeg no pudo convertir el archivo.")
        trabajo.salida = str(destino)
        self.verificar_formato_audio(destino, trabajo.formato, ffmpeg)

    @staticmethod
    def verificar_formato_audio(archivo: Path, formato: str, ffmpeg: str) -> None:
        """Comprueba el códec real, no solamente la extensión del archivo."""
        resultado = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(archivo)],
            capture_output=True, text=True, timeout=20, encoding="utf-8", errors="replace",
        )
        descripcion = resultado.stderr.casefold()
        codecs = {
            "mp3": ("audio: mp3",),
            "m4a": ("audio: aac", "audio: alac"),
            "aac": ("audio: aac",),
            "flac": ("audio: flac",),
            "wav": ("audio: pcm_",),
            "ogg": ("audio: vorbis",),
            "opus": ("audio: opus",),
        }
        if not any(codec in descripcion for codec in codecs[formato]):
            raise RuntimeError(f"FFmpeg creó el archivo, pero no pudo confirmar que sea {formato.upper()} real.")

    @staticmethod
    def obtener_duracion(ffmpeg: str, archivo: Path) -> float:
        resultado = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(archivo)],
            capture_output=True, text=True, timeout=20, encoding="utf-8", errors="replace",
        )
        coincidencia = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", resultado.stderr)
        if not coincidencia:
            return 0.0
        horas, minutos, segundos = coincidencia.groups()
        return int(horas) * 3600 + int(minutos) * 60 + float(segundos)

    def cancelar(self) -> None:
        if not self.trabajo_actual:
            return
        self.cancelar_actual.set()
        if self.proceso_actual and self.proceso_actual.poll() is None:
            self.proceso_actual.terminate()
        self.estado_general.set("Cancelando el trabajo actual...")

    def guardar_registro_error(self, titulo: str, error: str, detalle: str) -> Path:
        """Guarda información útil para diagnosticar fallos en otra computadora."""
        try:
            carpeta = Path(self.carpeta.get()).expanduser()
            carpeta.mkdir(parents=True, exist_ok=True)
        except OSError:
            carpeta = CONFIG_DIR
            carpeta.mkdir(parents=True, exist_ok=True)
        ruta = carpeta / "errores_Morales_Music_Tools.txt"
        with ruta.open("a", encoding="utf-8") as archivo:
            archivo.write("\n" + "=" * 70 + "\n")
            archivo.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
            archivo.write(f"Trabajo: {titulo}\nError: {error}\n\n{detalle}\n")
        return ruta

    def procesar_eventos(self) -> None:
        try:
            while True:
                evento = self.eventos.get_nowait()
                tipo = evento[0]
                if tipo == "inicio":
                    self.mostrar_actual(evento[1])
                elif tipo in ("actualizar", "progreso"):
                    self.actualizar_fila(evento[1])
                    if evento[1] is self.trabajo_actual:
                        self.mostrar_actual(evento[1], cargar_imagen=(tipo == "actualizar"))
                elif tipo == "terminado":
                    self.actualizar_fila(evento[1])
                    self.mostrar_actual(evento[1])
                    if evento[1].tipo in ("descarga", "video"):
                        self.quitar_de_listados(evento[1])
                    self.estado_general.set(f"Completado: {evento[1].titulo}")
                elif tipo == "playlist_inicio":
                    self.canciones_cargando = 0
                    nombre_lista, self.cargando_es_playlist, self.tipo_cargando = evento[1], evento[2], evento[3]
                    self.estado_general.set("Cargando canciones" + (f" — {nombre_lista}" if nombre_lista else "...") )
                elif tipo == "canciones_parciales":
                    canciones, nombre_lista, finalizado = evento[1], evento[2], evento[3]
                    nuevos_ids = []
                    for datos in canciones:
                        trabajo = Trabajo(
                            self.siguiente_id, datos["tipo"], datos["url"], datos["formato"],
                            calidad=datos["calidad"], titulo=datos["titulo"],
                            miniatura=datos["miniatura"], estado="Disponible",
                        )
                        nuevos_ids.append(str(self.siguiente_id))
                        self.siguiente_id += 1
                        self.agregar_trabajo(trabajo)
                    self.canciones_cargando += len(canciones)
                    self.estado_general.set(f"Agregando canciones: {self.canciones_cargando}")
                    if finalizado:
                        self.boton_agregar.configure(state="normal", text="Agregar enlace o playlist")
                        self.boton_agregar_video.configure(state="normal", text="Mostrar videos")
                        descripcion = f"Playlist agregada: {self.canciones_cargando} canciones" if self.canciones_cargando > 1 else "Canción agregada a la cola"
                        if nombre_lista and self.canciones_cargando > 1:
                            descripcion += f" — {nombre_lista}"
                        self.estado_general.set(descripcion)
                        if not self.cargando_es_playlist and nuevos_ids:
                            tabla_destino = self.tabla_video if self.tipo_cargando == "video" else self.tabla
                            tabla_destino.selection_set(nuevos_ids[-1])
                            tabla_destino.focus(nuevos_ids[-1])
                elif tipo == "enlace_error":
                    error, detalle = evento[1], evento[2]
                    self.boton_agregar.configure(state="normal", text="Agregar enlace o playlist")
                    self.boton_agregar_video.configure(state="normal", text="Mostrar videos")
                    ruta = self.guardar_registro_error("Lectura de enlace o playlist", error, detalle)
                    self.estado_general.set("No se pudo leer el enlace")
                    messagebox.showerror("No se pudo leer el enlace", f"{error}\n\nDetalle guardado en:\n{ruta}")
                elif tipo == "error":
                    trabajo, error, detalle = evento[1], evento[2], evento[3]
                    self.actualizar_fila(trabajo)
                    self.estado_general.set(f"Error en: {trabajo.titulo}")
                    ruta = self.guardar_registro_error(trabajo.titulo, error, detalle)
                    self.errores_cola.append(trabajo.titulo)
                    self.ultima_ruta_error = ruta
                elif tipo == "portada":
                    self.poner_portada(evento[1], evento[2])
                elif tipo == "cola_finalizada":
                    self.actual_texto.set("Cola finalizada")
                    self.siguiente_texto.set("Siguiente: ninguna")
                    self.video_actual_texto.set("Cola finalizada")
                    self.video_siguiente_texto.set("Siguiente: ninguno")
                    if self.errores_cola:
                        cantidad = len(self.errores_cola)
                        self.estado_general.set(f"Cola finalizada con {cantidad} error(es)")
                        messagebox.showwarning(
                            "Cola finalizada",
                            f"Se completó la cola con {cantidad} error(es).\n\n"
                            f"Los detalles están en:\n{self.ultima_ruta_error}",
                        )
                    else:
                        self.estado_general.set("Todos los trabajos fueron completados correctamente")
                self.actualizar_siguiente()
        except queue.Empty:
            pass
        self.after(100, self.procesar_eventos)

    def actualizar_fila(self, trabajo: Trabajo) -> None:
        valores = self.valores_trabajo(trabajo)
        for tabla in (self.tabla, getattr(self, "tabla_video", None)):
            if tabla is not None and tabla.exists(str(trabajo.id)):
                tabla.item(str(trabajo.id), values=valores)

    def quitar_de_listados(self, trabajo: Trabajo) -> None:
        """Oculta automáticamente una descarga que ya fue completada."""
        for tabla in (self.tabla, getattr(self, "tabla_video", None)):
            if tabla is not None and tabla.exists(str(trabajo.id)):
                tabla.delete(str(trabajo.id))

    @staticmethod
    def valores_trabajo(trabajo: Trabajo) -> tuple:
        formato = trabajo.formato.upper()
        if trabajo.tipo == "video" and trabajo.calidad:
            formato += " / " + trabajo.calidad
        return trabajo.titulo, formato, trabajo.estado, f"{trabajo.progreso:.0f}%"

    def mostrar_actual(self, trabajo: Trabajo, cargar_imagen: bool = True) -> None:
        detalles = [f"{trabajo.progreso:.0f}%"]
        if trabajo.velocidad:
            detalles.append(trabajo.velocidad)
        if trabajo.eta:
            detalles.append("Faltan " + trabajo.eta)
        if trabajo.tipo == "video":
            self.video_actual_texto.set(trabajo.titulo)
            self.progreso_video["value"] = trabajo.progreso
            self.video_detalle_texto.set("  •  ".join(detalles))
            portada_anterior = self.portada_video_url_actual
        else:
            self.actual_texto.set(trabajo.titulo)
            self.progreso["value"] = trabajo.progreso
            self.detalle_texto.set("  •  ".join(detalles))
            portada_anterior = self.portada_url_actual
        self.actualizar_fila(trabajo)
        if cargar_imagen and trabajo.miniatura and trabajo.miniatura != portada_anterior:
            if trabajo.tipo == "video":
                self.portada_video_url_actual = trabajo.miniatura
            else:
                self.portada_url_actual = trabajo.miniatura
            threading.Thread(
                target=self.cargar_portada, args=(trabajo.miniatura, trabajo.tipo), daemon=True
            ).start()

    def actualizar_siguiente(self) -> None:
        pendientes_audio = [x for x in self.trabajos if x.estado == "Pendiente" and x.tipo != "video"]
        pendientes_video = [x for x in self.trabajos if x.estado == "Pendiente" and x.tipo == "video"]
        self.siguiente_texto.set("Siguiente: " + (pendientes_audio[0].titulo if pendientes_audio else "ninguna"))
        self.video_siguiente_texto.set("Siguiente: " + (pendientes_video[0].titulo if pendientes_video else "ninguno"))

    def cargar_portada(self, url: str, tipo_trabajo: str) -> None:
        if Image is None:
            return
        try:
            peticion = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(peticion, timeout=15) as respuesta:
                datos = respuesta.read(5 * 1024 * 1024)
            imagen = Image.open(BytesIO(datos)).convert("RGB")
            imagen.thumbnail((330, 250))
            self.eventos.put(("portada", imagen.copy(), tipo_trabajo))
        except Exception:
            pass

    def poner_portada(self, imagen: Any, tipo_trabajo: str) -> None:
        if ImageTk is None:
            return
        if tipo_trabajo == "video":
            self.imagen_video_actual = ImageTk.PhotoImage(imagen)
            self.portada_video.configure(image=self.imagen_video_actual, text="", width=330, height=250)
        else:
            self.imagen_actual = ImageTk.PhotoImage(imagen)
            self.portada.configure(image=self.imagen_actual, text="", width=330, height=250)

    def cerrar(self) -> None:
        if self.procesando and not messagebox.askyesno("Cerrar", "Hay un trabajo en proceso. ¿Desea cancelarlo y salir?"):
            return
        self.cancelar_actual.set()
        if self.proceso_actual and self.proceso_actual.poll() is None:
            self.proceso_actual.terminate()
        self.guardar_configuracion()
        self.destroy()


def mostrar_apertura() -> None:
    """Muestra una breve animación de marca antes de abrir la interfaz."""
    splash = tk.Tk()
    splash.overrideredirect(True)
    splash.configure(bg="#080c12")
    ancho, alto = 560, 610
    x = max(0, (splash.winfo_screenwidth() - ancho) // 2)
    y = max(0, (splash.winfo_screenheight() - alto) // 2)
    splash.geometry(f"{ancho}x{alto}+{x}+{y}")
    try:
        splash.attributes("-alpha", 0.0)
        splash.attributes("-topmost", True)
    except tk.TclError:
        pass

    marco = tk.Frame(splash, bg="#080c12", highlightbackground="#18d97b", highlightthickness=2)
    marco.pack(fill="both", expand=True, padx=8, pady=8)
    logo_tk = None
    logo = ruta_recurso(LOGO_ARCHIVO)
    if logo.is_file() and Image is not None and ImageTk is not None:
        try:
            imagen = Image.open(logo).convert("RGBA")
            imagen.thumbnail((430, 430))
            logo_tk = ImageTk.PhotoImage(imagen)
            etiqueta_logo = tk.Label(marco, image=logo_tk, bg="#080c12", borderwidth=0)
        except OSError:
            etiqueta_logo = tk.Label(marco, text="MMT", font=("Segoe UI Black", 74), bg="#080c12", fg="#26e884")
    else:
        etiqueta_logo = tk.Label(marco, text="MMT", font=("Segoe UI Black", 74), bg="#080c12", fg="#26e884")
    etiqueta_logo.pack(pady=(30, 6))
    tk.Label(marco, text="MORALES MUSIC TOOLS", font=("Segoe UI Semibold", 20), bg="#080c12", fg="white").pack()
    tk.Label(marco, text="Creado por Marcos Morales  •  @mmb_morales", font=("Segoe UI", 10), bg="#080c12", fg="#8ba1b5").pack(pady=(5, 20))
    barra = ttk.Progressbar(marco, maximum=100, length=390, style="Green.Horizontal.TProgressbar")
    barra.pack(pady=(2, 8))
    estado = tk.Label(marco, text="Iniciando...", font=("Segoe UI", 10), bg="#080c12", fg="#39dff5")
    estado.pack()

    mensajes = ((0, "Iniciando..."), (28, "Cargando herramientas de audio..."),
                (62, "Preparando la interfaz..."), (88, "Todo listo"))

    def animar(paso: int = 0) -> None:
        valor = min(100, paso * 2)
        barra["value"] = valor
        for limite, mensaje in mensajes:
            if valor >= limite:
                estado.configure(text=mensaje)
        try:
            splash.attributes("-alpha", min(1.0, paso / 12))
        except tk.TclError:
            pass
        if paso < 50:
            splash.after(35, animar, paso + 1)
        else:
            splash.after(350, splash.destroy)

    # Conserva la referencia de la imagen durante toda la animación.
    splash._logo_tk = logo_tk
    splash.after(40, animar)
    splash.mainloop()


def main() -> None:
    try:
        instalar_componentes_automaticamente()
        mostrar_apertura()
        app = AudioFacil()
        app.mainloop()
    except tk.TclError as error:
        print("No se pudo abrir la interfaz visual:", error)
        print("Ejecute este programa en una computadora con escritorio gráfico.")


if __name__ == "__main__":
    main()

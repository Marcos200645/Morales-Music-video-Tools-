@echo off
title Instalar Morales Music Tools
cd /d "%~dp0"
color 0A
echo ==================================================
echo        INSTALAR MORALES MUSIC TOOLS
echo ==================================================
echo.
where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado.
    echo Descarguelo desde https://www.python.org/downloads/
    echo y marque la opcion Add Python to PATH.
    pause
    exit /b 1
)
py -m pip install --upgrade yt-dlp Pillow imageio-ffmpeg
if errorlevel 1 (
    echo No se pudieron instalar los componentes. Revise su conexion.
    pause
    exit /b 1
)
echo.
echo Motor FFmpeg instalado dentro del programa.
echo Instalacion terminada.
pause

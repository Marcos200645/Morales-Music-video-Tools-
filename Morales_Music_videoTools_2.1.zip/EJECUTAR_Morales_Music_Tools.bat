@echo off
cd /d "%~dp0"
py Morales_Music_Tools.py
if errorlevel 1 pause
